package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.utility.JdbcUtility;

import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoImpl implements ContactBookDao {

	Connection connection = null;
	PreparedStatement statement = null;
	static Logger logger = Logger.getLogger(ContactBookDaoImpl.class);

	
	
	/**
	 * 
	 __________________________________________________________________
	 
	 - Function Name	:	getEnquiryDetails(int EnquiryID)	
	 - Input Parameters	:	EnquiryID
	 - Return Type		:	EnquiryBean class object
	 - Throws			:  	ContactBookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	29/10/2018
	 - Description		:	getting details from database
	 ______________________________________________________________________
	 *  
	 */
	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException {
		logger.info("In getting enquiry details  mehtod..");

		connection = JdbcUtility.getConnection();
		try {
			statement = connection.prepareStatement(QueryConstants.getDetails);
			statement.setInt(1, EnquiryID);
			ResultSet resultSet = null;

			resultSet = statement.executeQuery();

			resultSet.next(); // result has the details from database
			EnquiryBean eb1 = new EnquiryBean();

			eb1.setEnqryId(resultSet.getInt(1));
			eb1.setfName(resultSet.getString(2));
			eb1.setlName(resultSet.getString(3));
			eb1.setContactNo(Long.toString(resultSet.getLong(4))); // as the
																	// contact
																	// number is
																	// string in
																	// bean
																	// class
																	// convert
																	// it from
																	// long to
																	// string
																	// type
			eb1.setpDomain(resultSet.getString(5));
			eb1.setpLocation(resultSet.getString(6));

			return eb1; // retuning the bean object to Client class for
						// displaying purposes

		} catch (SQLException e) {
			logger.error("In enquiry details method exception  is: "
					+ e.getMessage());
			throw new ContactBookException(" Sorry no details found as the Id entered is incorrect!!");
		}

	}
	/**
	 ____________________________________________________________________
	 
	 - Function Name	:	addEnquiry(EnquiryBean enqry)	
	 - Input Parameters	:	EnquiryBean class object
	 - Return Type		:	integer type
	 - Throws			:  	ContactBookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	29/10/2018
	 - Description		:	returns the unique id
	 ______________________________________________________________________
	 */
	
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {

		logger.info("In add enquiry deatils  method..");
		connection = JdbcUtility.getConnection();

		try {
			statement = connection.prepareStatement(QueryConstants.insertQuery);
			statement.setString(1, enqry.getfName());
			statement.setString(2, enqry.getlName());
			statement.setLong(3, Long.parseLong(enqry.getContactNo())); // as
																		// the
																		// contact
																		// number
																		// is
																		// stringtype
																		// in
																		// bean
																		// class
																		// convert
																		// it to
																		// long
																		// and
																		// store
																		// in
																		// database
			statement.setString(4, enqry.getpDomain());
			statement.setString(5, enqry.getpLocation());

			int r = statement.executeUpdate();

			statement = connection.prepareStatement(QueryConstants.getIdQuery);
			ResultSet rs = statement.executeQuery();
			rs.next();
			int id = rs.getInt(1); // an unique Id is generated
			return id;

		} catch (SQLException e) {
			logger.error("In add enquiry meathod exception came..");
			e.printStackTrace();
			throw new ContactBookException(
					"sorry the details can't be added to database");

		}

	}

}
