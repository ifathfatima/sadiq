package com.cg.eis.exception;					//6.3 prog part

public class EmpException extends Exception
{
	
	public EmpException()
	{
		super("sal is less than 3000");
		
		
		
	}
	
	
										//9.2.2 prog part
	public String  getMessage()
	{
	String mess="sal is less than 3000";
	return mess;
	}
	
	
}
