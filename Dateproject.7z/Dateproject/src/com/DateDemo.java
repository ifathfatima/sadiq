package com;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class DateDemo {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter date:");
		String date = scanner.nextLine();

		LocalDate localDate = LocalDate.parse(date);
		System.out.println(localDate);

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");

		String out = localDate.format(formatter);
		System.out.println(out);
	}

}
