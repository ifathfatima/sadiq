package com.cg.library;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class SelectLibrary {

	public static void main(String[] args) {
		
		EntityManagerFactory emf1=Persistence.createEntityManagerFactory("Library Management");
		EntityManager em1=emf1.createEntityManager();
		em1.getTransaction().begin();
		
			
		Query q=em1.createNamedQuery("select_library");
		
		List<Library> list=q.getResultList();	//return the obj in list type
		for(Library lib:list)
		{
			System.out.println("==========================");
			System.out.println("Id:"+lib.getId());
			System.out.println("Name:"+lib.getBookname());
			System.out.println("Price:"+lib.getBookprice());
			
		}
		
		em1.getTransaction().commit();
		em1.close();
		emf1.close();
		
		
		
		
	}
	

}
