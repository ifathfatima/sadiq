package LamdaExp;
interface CanvasHtml5
{
	public void  draw();
	
}
public class WithOutLamda {
	public static void main(String args)
	{
		
	}

}
