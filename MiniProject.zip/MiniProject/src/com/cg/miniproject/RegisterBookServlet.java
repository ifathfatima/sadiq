package com.cg.miniproject;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.miniproject.dao.UserDao;

/**
 * Servlet implementation class RegisterBookServlet
 */
@WebServlet("/RegisterBookServlet")
public class RegisterBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out= response.getWriter();
		  
		  
		  String regId=request.getParameter("regId");
		  String bookId=request.getParameter("bookId");
		  String userId = request.getParameter("userId");
		  
		  
		  
		  
		  
		  UserDao dao= new UserDao();
		  
		  int n= dao.registerBook(regId, bookId, userId);
		  
		  
		  if(n>0)
		  {
		   out.println("Successfully registered");
		   RequestDispatcher rd = request.getRequestDispatcher("student.jsp");
		   
		   rd.include(request, response);
		    
		  }
		  else
		  { out.println("Something went wrong please try again");
		   
		   RequestDispatcher rd = request.getRequestDispatcher("registerbook.jsp");
		   
		   rd.include(request, response);
		  }
		  
		  
		  
		  
		
		
		
	}

}
