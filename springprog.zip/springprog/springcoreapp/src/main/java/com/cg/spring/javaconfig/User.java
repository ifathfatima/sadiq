package com.cg.spring.javaconfig;

import org.springframework.beans.factory.annotation.Autowired;

public class User {
	
	
	private String name;
	@Autowired
	private Product p;
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Product getP() {
		return p;
	}
	public void setP(Product p) {
		this.p = p;
	}
	@Override
	public String toString() {
		return "User [name=" + name + ", p=" + p + "]";
	}
	
	

}
