package com.example.demo;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface ICustomerService   {
	
	public List<Customer> getAll();
	
	
	//public Customer getCusById(Integer id);
	
	public void addCustomer(Customer c);
	
	public void deleteById(Integer id);
	
	public void updateCustomer(Customer c);
	
	
	
	
	
	

}
