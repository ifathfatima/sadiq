package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlet.dao.UserDao;

/**
 * Servlet implementation class LoggingServlet
 */
@WebServlet("/LoggingServlet")
public class LoggingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String username = request.getParameter("user");
		String password = request.getParameter("pass");
		
		
		
		UserDao dao=new UserDao();  
		boolean flag=dao.validateUser(password);
		if(flag)
		{
			response.sendRedirect("home.jsp");
			
		}
		
		else
		{
			out.println("<b style='color:red;'> user not valid user</b>");
			RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
			rd.include(request, response);
			
		}
		/*
		if (username.equals(g.getInitParameter("username")) && password.equals(g.getInitParameter("password")))	//when ever the admin changs then change it here but we don't want to change here
			
		{
			//RequestDispatcher rd = request.getRequestDispatcher("https://www.google.com/");
			//rd.forward(request, response);
			
			response.sendRedirect("welcome.jsp");	//for sending request outside the application to google and send redirect does not work with dopost() method
			

		} else {

			out.println("<b> user not registered yet. plz register now.</b>");
			RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
			rd.include(request, response);
		*/
		
		
		
	}

}
