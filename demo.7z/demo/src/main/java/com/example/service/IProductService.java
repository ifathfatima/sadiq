package com.example.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.bean.Product;

@Service
public interface IProductService {
	
	
	List<Product> getAllProduct();
	Product getProductById(int id);
	 List<Product> delete(int id);
	 String addProduct(String name,double price);
	 String updateProduct(int id,String name,double price);
	 

}
