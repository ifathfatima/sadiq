package com.cg.spring.jpa.springdata.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.spring.jpa.springdata.bean.Product;
import com.cg.spring.jpa.springdata.repository.IProductRepo;

@Component
public class ProductServiceImpl implements IProductService {

	
	
	
	
	@Autowired
	IProductRepo repo;
	
	@Override
	public List<Product> getAllProduct() {
		
		return repo.getAllProduct();
		
	}

	@Override
	public void addProduct(int id,String name,double price) {
		repo.addProduct(id,name,price);
			
		
	}

	@Override
	public void updatProduct(int id, String name, double price) {
		repo.updatProduct(id,name,price);
		
	}

	@Override
	public void deletProduct(int id) {
		
		repo.deletProduct(id);
	}

	@Override
	public Product geProduct(int id) {
		
		return repo.geProduct(id);
	}

	@Override
	public List<Product> getProductByName(String name) {
		
		return repo.getProductByName(name);
	}

}
