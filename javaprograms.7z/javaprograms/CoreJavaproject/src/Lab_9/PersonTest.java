package Lab_9;                               //9.1   2/2 prog
import org.junit.*;
import org.junit.Test;
import static org.junit.Assert.*;


public class PersonTest 
{
	@Test
	public void testGetFullName()
	{
		System.out.println("from TestPerson1");
		Person p1 = new Person("Robert","King");
		assertEquals("Robert King",p1.getFullName());
	}
	
	@Test (expected=IllegalArgumentException.class)
	public void testNullsInName()
	{
	System.out.println("from TestPerson1 testing exceptions");
	Person p1 = new Person(null,null);		
	}
	@Test
	public void testFullName()
	{
		System.out.println("from TestPerson2");
		Person p2=new Person("ifath","fatima");
		assertEquals("ifath fatima",p2.getFullName());
	}
	@Test
	public void testFullNmae()
	{
		Person p3=new Person("","fatima");
		assertEquals("ifath fatima",p3.getFullName());
	}


}
