package SirClassprog;

class Deletre 
{
 public void m1()
 {
	 System.out.println("1");
 }

}
class Bee extends Deletre
{
	public void m2()
	{
		System.out.println("this id child");
	}
	
}
 class Demo 
{
	public static void main(String args[])
	{
		Deletre d= new Bee();			//Bee b1=new Deletre(); this is not allowed in java giving parent objetc to child reference
		//d.m2();
		Bee b1=new Bee();
		//b1.m1();
		//b1.m2();
		d=b1;
		d.m2();			//this is child is output
		d.m1();			//even when child does not have the m1() it inherits the method from parent the same is not 
						//possible vice versa ...whether the parent might be class or interface the same is not possible
						//even if  we give parentobj=childobj; then also if parent does not have the method it cannot access that 
						//perentobj=childobj; works and returns child values only when the parent also has the same method
	}
}