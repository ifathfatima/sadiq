package com.cg.mobile.service;

import java.util.List;

import com.cg.mmobile.dao.IMobileDao;
import com.cg.mmobile.dao.MobileDaoImpl;
import com.cg.mobile.bean.Mobile;
public class MobileServiceImpl implements IMobileService {
	
	
	IMobileDao dao= new MobileDaoImpl();
	@Override
	public String display()
	{
		return dao.display();
	}
	@Override
	 public List<Mobile> getMobileByPrice(double price)
	 {
		return dao.getMobileByPrice(price);
		
	 }
	@Override
	public List<Mobile> getAllMobile()
	{
		return dao.getAllMobile();
	}
}
