package com.cg.mmobile.dao;

import java.sql.*;
import java.util.*;

import com.cg.mobile.bean.Mobile;
import com.exceptions.MobileException;
import com.utility.JdbcUtility;
import com.cg.mobile.bean.Customer;
import com.cg.mmobile.dao.QueryConstants;
import com.utility.*;


public class MobileDaoImpl implements IMobileDao 
{

	@Override
	public String display()
	{

		return "demo for mobile app";
	}

	@Override
	public List<Mobile> getMobileByPrice(double price) {

		try { // case 5
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String user = "system";
			String pass = "Capgemini123";
			Connection con = DriverManager.getConnection(url, user, pass);
			String sql = "select * from mobiles where price >=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setDouble(1, price);
			ResultSet rs = ps.executeQuery();
			Mobile m = null;
			;
			List<Mobile> list = new ArrayList<>();
			while (rs.next()) {
				m = new Mobile();
				m.setMobileId(rs.getInt(1));
				m.setName(rs.getString(2));
				m.setPrice(rs.getDouble(3));
				m.setQuantity(rs.getString(4));
				list.add(m);
			}
			return list;
		} catch (Exception e) {

		}
		return null; // if exception occurs then return null

	}

	@Override
	public List<Mobile> getAllMobile() {
		try { // case 3
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String user = "system";
			String pass = "Capgemini123";
			Connection con = DriverManager.getConnection(url, user, pass);
			String sql = "select * from mobiles ";
			PreparedStatement ps = con.prepareStatement(sql);

			ResultSet rs = ps.executeQuery();
			Mobile m = null;
			;
			List<Mobile> list = new ArrayList<>();
			while (rs.next()) {
				m = new Mobile();
				m.setMobileId(rs.getInt(1));
				m.setName(rs.getString(2));
				m.setPrice(rs.getDouble(3));
				m.setQuantity(rs.getString(4));
				list.add(m);
			}
			return list;
		} catch (Exception e) {

		}
		return null;
	}

	@Override
	// case 4
	public String deleteMobile(int mobileId)
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String user = "system";
			String pass = "Capgemini123";
			Connection con = DriverManager.getConnection(url, user, pass);
			String sql = "delete from mobiles where mobileid=? ";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, mobileId);
			int r = ps.executeUpdate();
			return (r + " " + "row deleted from mobiles table");
			/*
			 * Mobile m=null;; List<Mobile> list=new ArrayList<>();
			 * while(rs.next()) //as the executeupdate() return an interger
			 * value { m=new Mobile(); m.setMobileId(rs.getInt(1));
			 * m.setName(rs.getString(2)); m.setPrice(rs.getDouble(3));
			 * m.setQuantity(rs.getString(4)); list.add(m); } return list;
			 */
		} 
		catch (Exception e)
		{

		}
		return null;
	}


	@Override
	// case 1
	public int store(Customer customer) throws MobileException 
	{
		Connection connection = null;
		PreparedStatement statement = null;

		int quantity = getQuantity(customer.getMobileId());		//takes input of quantity from user and check 
		
		connection = JdbcUtility.getConnection();

		int id = 0;

		if (customer.getquantity() <= quantity)
		{

			try 
			{
				statement = connection
						.prepareStatement(QueryConstants.insertQuery);			//inserting the new row into customer table after checking
				statement.setString(1, customer.getCname());
				statement.setString(2, customer.getCmailid());
				statement.setLong(3, customer.getCph());
				statement.setInt(4, customer.getMobileId());

				statement.executeUpdate();

				id = getId();
			}
			catch (SQLException e)
			{
				throw new MobileException("statement not created");
			}
		}
		return id;
	}
		
	int getQuantity(int mobileId) throws MobileException 
	{
		Connection connection = null;
		PreparedStatement statement = null;

		connection = JdbcUtility.getConnection();
		int quantity = 0;
		try {

			statement = connection
					.prepareStatement(QueryConstants.checkIdQuery);		//used for retrieving the quantity of mobile from mobile_test table depending on mobileid
			statement.setInt(1, mobileId);

			ResultSet resultSet = statement.executeQuery();

			resultSet.next();

			quantity = resultSet.getInt(1);

		} catch (SQLException exception) {
			throw new MobileException("statement not cretaed..");
			//exception.printStackTrace();				//to trace error but not in m2 exam use it
		}
		return quantity;

	}

	public int getId() throws MobileException 
	{
		Connection connection = null;
		PreparedStatement statement = null;

		connection = JdbcUtility.getConnection();
		int id = 0;
		try {

			statement = connection.prepareStatement(QueryConstants.getId);

			ResultSet resultSet = statement.executeQuery();

			resultSet.next();

			id = resultSet.getInt(1);

		} catch (SQLException exception) 
		{
			throw new MobileException("statement not cretaed..");
			//exception.printStackTrace();
		}
		return id;

	}
	

}

