package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlet.dao.UserDao;

/**
 * Servlet implementation class UpdatePasswordServlet
 */
@WebServlet("/UpdatePasswordServlet")
public class UpdatePasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String phonenumber = request.getParameter("phone");
		String newpassword = request.getParameter("pass");
		String confirmpassword = request.getParameter("cpass");

		UserDao dao = new UserDao(); // as we now connectin gto databse using
										// setvletcontext concept
		int n = dao.updatePassword(phonenumber, newpassword);

		if (newpassword.equals(confirmpassword)) 
		{
			if (n > 0) 
			{
				out.println("successfully update the password into D.B");
				RequestDispatcher rd = request
						.getRequestDispatcher("login.jsp");
				rd.include(request, response);

				// response.sendRedirect("login.jsp");
			}

			else
			{
				out.println("<b style='color:red;'>something went wrong plz try to update the password again </b>");
				RequestDispatcher rd = request
						.getRequestDispatcher("updatepassword.jsp");
				rd.include(request, response);

				// response.sendRedirect("register.jsp?emsg=something went wrong.register again. ");
			}

		} else {
			out.println("<b style='color:red;'>the password and new password should be same</b>");
			RequestDispatcher rd = request
					.getRequestDispatcher("updatepassword.jsp");
			rd.include(request, response);
		}

	}

}
