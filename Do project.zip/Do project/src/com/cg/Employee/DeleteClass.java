package com.cg.Employee;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DeleteClass {
	
	public void deleteNow()
	{
		
		
		EntityManagerFactory emf2=Persistence.createEntityManagerFactory("Do project");
		EntityManager em2=emf2.createEntityManager();
		em2.getTransaction().begin();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter the id which you want to delete from D.B");
		int i=sc.nextInt();
		Employee e3=em2.find(Employee.class, i);
		
		if(e3==null)
		{
			System.out.println("the employee is not in D.B");
		}
		else
		{
		em2.remove(e3);
		
		
		System.out.println("delete the row from D.B.......");
		
		em2.getTransaction().commit();
		em2.close();
		emf2.close();
	}

}
}
