package com.cg.mobile.bean;

import java.time.LocalDate;
import java.util.Date;

public class Customer {
	private String cname;
	private long cph;			//always give full name for var in prog 
	private String cmailid;
	private LocalDate date;
	private int mobileId;
	private int quantity;

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public long getCph() {
		return cph;
	}

	public void setCph(long cph) {
		this.cph = cph;
	}

	public String getCmailid() {
		return cmailid;
	}

	public void setCmailid(String cmailid) {
		this.cmailid = cmailid;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}

	public int getMobileId() {
		return mobileId;
	}

	public int getquantity() {
		return quantity;
	}

	public void setquantity(int quantity) {
		this.quantity = quantity;
	}

	public Customer(String cname, int mobileId, int quantity,LocalDate date) {
		super();
		this.cname = cname;
		this.mobileId = mobileId;
		this.quantity = quantity;
		this.date=date;
	}

	/*@Override
	public String toString() {
		return "Customer [cname=" + cname + ", cph=" + cph + ", cmailid="
				+ cmailid + ", date=" + date + ", mobileId=" + mobileId
				+ ", quantity=" + quantity + "]";
	}
	 */
}