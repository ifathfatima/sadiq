package SirClassprog;

public class HelloMain extends Thread {

	public static  void main(String[] args) 
	{
		// TODO Auto-generated method stub
		//Hello h=new Hello();
		//h.start();
		//h.display();
		try{
			
		System.out.println(Thread.currentThread().getName());
		 
		 System.out.println(Thread.currentThread().getPriority());
		 currentThread().sleep(10);
		}
		catch(InterruptedException e)
		{
			
		}
		
		 Hello h=new Hello();
		 Hello h2=new Hello();
		 //Thread t1=new Thread(h);
		// Thread t2=new Thread(h);
		 h.setPriority(Thread.MIN_PRIORITY);
		
		 
		
		h2.setPriority(Thread.MAX_PRIORITY);
		 h.start();
		 h2.start();
		 
		 
		 
	}

}
