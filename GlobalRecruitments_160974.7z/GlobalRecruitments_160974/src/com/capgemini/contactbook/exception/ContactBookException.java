package com.capgemini.contactbook.exception;

public class ContactBookException extends Exception { // creating exceptions
														// class
	private String message;

	public ContactBookException(String message) {
		super();
		this.message = message; // assigning value to message
	}

	public String getMessage() {
		return message;
	}

}
