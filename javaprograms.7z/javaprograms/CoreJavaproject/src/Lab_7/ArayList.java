package Lab_7;								//7.2 PROG not accoding to questuions
import java.util.*;
public class ArayList 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		ArrayList<String> al=new ArrayList<String>();  
		al.add("EGGS");  
		al.add("MILK");  
		al.add("HONEY");  
		al.add("APPLE");  
		  
		Collections.sort(al);  
	/*Iterator itr=al.iterator();  
		while(itr.hasNext())
		{  
		System.out.println(itr.next());  
		*/
		for(String a:al)
		{
			System.out.println(a);
		}

	}
}
