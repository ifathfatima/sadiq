package com.cg.Employee;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;



public class ViewClass {
	
	public void viewNow()
	{
		EntityManagerFactory emf1=Persistence.createEntityManagerFactory("Do project");
		EntityManager em1=emf1.createEntityManager();
		em1.getTransaction().begin();
		
			
		Query q=em1.createQuery("select  emp from Employee emp");		//here only the bean class name is accepted but not the table name
		
		List<Employee> list=q.getResultList();	//return the obj in list type
		for(Employee lib:list)
		{
			System.out.println("==========================");
			System.out.println("Id:"+lib.getId());
			System.out.println("Name:"+lib.getName());
			System.out.println("Price:"+lib.getSalary());
			
		}
		//em1.persist(list);
		em1.getTransaction().commit();
		em1.close();
		emf1.close();
		
	}

}
