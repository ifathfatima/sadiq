package com.cg.cpring.mvc.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;


import com.ch.spring.mvc.bean.Employee;



@Component
public class EmpRepoImpl implements EmpRepo {

	
	
	List<Employee> list=new ArrayList();
	
	
	public List<Employee> getEmployee() {
		
		return list;
	}
	
	
	
	
	
	
	
	
	
	public void add(Employee p) {
		
		Employee p1=new Employee();
		p1.setId(list.size()+1);
		p1.setName("ifath");
		p1.setSalary(50000);
		list.add(p1);
		
		
		Employee p2=new Employee();
		p2.setId(list.size()+1);
		p2.setName("mashu");
		p2.setSalary(60000);
		list.add(p2);
		
		
		
		Employee p3=new Employee();
		p3.setId(list.size()+1);
		p3.setName("windows s4");
		p3.setSalary(60000);
		list.add(p3);
		
		p.setId(list.size()+1);
		list.add(p);  //adding the product 
		
	}


	public Employee searchById(int id) 
	{
		
		
		
		
		for(Employee p:list)
		{
			if(p.getId()==id)
			{
				return p;
				
			}
		}
		
		
		return null;
	}









	public Employee updateById(int id) {
		
		
		for(Employee p:list)
		{
			if(p.getId()==id)
			{
				return p;
				
			}
		}
		
		return null;
	}









	public void  deleteById(int id) {
		
		

		for(Employee p:list)
		{
			if(p.getId()==id)
			{
				list.remove(p);
				
				
			}
		}
		
		
		
		
	}


}
