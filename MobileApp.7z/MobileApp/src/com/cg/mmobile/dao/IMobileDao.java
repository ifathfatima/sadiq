package com.cg.mmobile.dao;

import java.util.List;



import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;
import com.exceptions.MobileException;



public interface IMobileDao {
	
	public String display();
	 public List<Mobile> getMobileByPrice(double price);
	 public List<Mobile> getAllMobile();
	 public String deleteMobile(int mobileId);
	 public  int store(Customer customer) throws MobileException;
}
