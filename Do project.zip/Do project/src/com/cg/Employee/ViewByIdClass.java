package com.cg.Employee;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;



public class ViewByIdClass {
	
	public void viewById()
	{
		
		
		EntityManagerFactory emf2=Persistence.createEntityManagerFactory("Do project");
		EntityManager em2=emf2.createEntityManager();
		em2.getTransaction().begin();
		
		
		
		System.out.println("enter the id for which you want  to see the details");
		Scanner sc=new Scanner(System.in);
		
		//int id=sc.nextInt();
		Employee e5=em2.find(Employee.class, sc.nextInt());
		
		if(e5==null)
		{
			System.out.println("the employee is not in D.B ");
		}
		else
		{
			
				System.out.println("==========================");
				System.out.println("Id:"+e5.getId());
				System.out.println("Name:"+e5.getName());
				System.out.println("Price:"+e5.getSalary());
				
			
			
		}
		
		
		
		em2.getTransaction().commit();
		em2.close();
		emf2.close();
		
	
	
	}

}
