package com.capgemini.tcc.dao;

import com.capgemini.tcc.bean.Patient;
import com.capgemini.tcc.exception.TakeCareException;

public interface TakeCareDAO {

	
	public int addPatientDetails(Patient p) throws  TakeCareException;
	
	public Patient searchPatientDetails(int id) throws  TakeCareException;
}
