package com.cg.library;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class DeleteLibrary {
	
public static void main(String[] args) {
		
		EntityManagerFactory emf2=Persistence.createEntityManagerFactory("Library Management");
		EntityManager em2=emf2.createEntityManager();
		em2.getTransaction().begin();
		
		
		
		Library l2=em2.find(Library.class, 5);
		em2.remove(l2);
		
		
		System.out.println("delete done.......");
		
		
		/*
		
		Query query = em2.createNativeQuery("DELETE FROM Library lib WHERE lib.id =5");
		
		
		int i=query.executeUpdate();
		if(i>0)
		{
			System.out.println("delete done");
		}
		else
		{
			System.out.println("delete  not done");
			
		}
		*/
		
		
		
		em2.getTransaction().commit();
		em2.close();
		emf2.close();
		
		
		
		
	}
	

}
