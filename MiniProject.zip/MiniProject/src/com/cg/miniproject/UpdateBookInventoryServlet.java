package com.cg.miniproject;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.miniproject.dao.UserDao;



/**
 * Servlet implementation class UpdateBookInventoryServlet
 */
@WebServlet("/UpdateBookInventoryServlet")
public class UpdateBookInventoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String id = request.getParameter("bid");
		String name = request.getParameter("bname");
		

		UserDao dao = new UserDao(); // as we now connectin gto databse using
										// setvletcontext concept
		int n = dao.updateBooK(id, name);

		
			if (n > 0) 
			{
				out.println("successfully update the book details in D.B");
				RequestDispatcher rd = request
						.getRequestDispatcher("librarianhomepage.jsp");
				rd.include(request, response);

				// response.sendRedirect("login.jsp");
			}

			else
			{
				out.println("<b style='color:red;'>something went wrong plz try to update the book deatisl again </b>");
				RequestDispatcher rd = request
						.getRequestDispatcher("bookinventory.jsp");
				rd.include(request, response);

				// response.sendRedirect("register.jsp?emsg=something went wrong.register again. ");
			}

		
		}

	}


