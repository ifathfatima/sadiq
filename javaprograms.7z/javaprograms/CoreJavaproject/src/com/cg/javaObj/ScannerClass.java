package com.cg.javaObj;
import java.util.*;

public class ScannerClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a;float b;String st;
		Scanner sc= new Scanner(System.in);
		System.out.println("enter number");
		a=sc.nextInt();
		System.out.println(a);


		
	}

}
