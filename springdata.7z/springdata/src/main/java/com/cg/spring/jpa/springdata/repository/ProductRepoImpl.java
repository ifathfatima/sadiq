package com.cg.spring.jpa.springdata.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.cg.spring.jpa.springdata.bean.Product;
@Component
public class ProductRepoImpl  implements IProductRepo{

	
	List<Product> list=new ArrayList<Product>();
	
	@Autowired
	EntityManager entitymanager;
	
	
	
	@Override
	public List<Product> getAllProduct() {
		
		Query q=entitymanager.createQuery("from Product");
		list=q.getResultList();
		
		
		return list;
	}



	@Override
	@Transactional
	public void addProduct(int id,String name,double price) {
		
		Product p1=new Product();
		p1.setId(id);
		p1.setName(name);
		p1.setPrice(price);
		
		entitymanager.persist(p1);
		
		
		
	}



	@Override
	@Transactional
	public void updatProduct(int id, String name, double price) {
		
		Product p2=entitymanager.find(Product.class,id);
		
		
			
			p2.setName(name);
			p2.setPrice(price);
			entitymanager.persist(p2);
				
	}



	@Override
	@Transactional
	public void deletProduct(int id) {
		Product p2=entitymanager.find(Product.class,id);
		
	
		entitymanager.remove(p2);
		
	}



	@Override
	public Product geProduct(int id) {
		
		
		//Product p2=entitymanager.find(Product.class,id);
		
		Query q=entitymanager.createQuery("from Product p where p.id=:id");
		q.setParameter("id", id);
		Product p2=(Product) q.getSingleResult();
		
		return p2;
		
	}



	@Override
	public List<Product> getProductByName(String name) {
		
		List<Product> l1=new ArrayList<Product>();
		for (Product p : list)
		{
			if (p.getName().equals(name))
				{
					l1.add(p);
				}
		}

		return l1;
		
		
	}

}
