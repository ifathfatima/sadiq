package Lab_8;					//8.2 prog wrong porgram

import java.io.*;
import java.util.*;

public class EvenConsole 
{

	public static void main(String[] args)
	{
		
		try
		{
			FileReader fr= new FileReader("D:\\number.txt");
			BufferedReader br=new BufferedReader(fr);
			Scanner s=new Scanner(fr);
			int i=0;
			//int k=0;
			//ArrayList a1=new ArrayList();
			//int b[]=new int[10];		//declare and int array of length 10
			while(s.hasNext())
			{
				
				
			String	a1=s.nextLine();
			for(i=0;i<20;i++)
			{
				char ch=a1.charAt(i);
				
				System.out.println(ch);
			}
			}
				//System.out.println(k);
				
				
				
				//now a1 has the complete string i,e "1,2,3,4,5,6,7,8,9,10". now split the string
				/*String[] a2=a1.split(",");
				Integer[] p=new Integer[a2.length];//a2 has '1','2','3','4','5','6','7','8','9','10'	
				for(String a3:a2)
				{
				 p[i]=Integer.parseInt(a1);  			//now p[] has the Integer array 
				 i++;
				}
				for(int j=0;j<p.length;j++)
				{
					b[j]=p[j];	//unboxing or converting Integer to int array
				}
				for(int q=0;q<b.length;q++)
				{
					if(b[q]%2==0)
					{
						System.out.println(b[q]);
					}
					
				}
				//i=s.nextInt();
				*/
				
				
				
			
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
	}

}
