package Lab_8;					//8.1 prog correct output

import java.io.*;
import java.lang.*;

public class FileReverse 
{

	public static void main(String[] args)
	{
		try
		{
			FileReader fr= new FileReader("D:\\abc.txt");
			FileWriter fw=new FileWriter("D:\\bcd.txt");    		//donot create this file the vprog will create on its own
			BufferedReader br = new BufferedReader(fr); 
			String line;
			String a;//reverse the line eg:i am ifath
			String rev="";													// o/p: htafi ma i
			while((line= br.readLine())!=null)
			{
				a=new String(line);
				for(int i=a.length()-1;i>=0;i--)
				{
					rev=rev+a.charAt(i);
					
				}
			}
			fw.write(rev);
			System.out.println(rev);
			fw.close();
		}
		
		catch(IOException e)
		{
			System.out.println(e);
		}

	}

}
