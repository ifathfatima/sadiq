package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoggingServlet
 */
@WebServlet("/LoggingServlet")
public class LoggingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String username = request.getParameter("user");
		String password = request.getParameter("pass");
		
		
		
		  HttpSession hs=request.getSession();
			hs.setAttribute("uname",username);
			
		
		
		
		
		Cookie c1=new Cookie("uname",username);
		Cookie c2=new Cookie("pass", password);
		response.addCookie(c1);
		response.addCookie(c2);
		
		
		
		
		
		
		ServletContext sc= getServletContext();
		try
		{
			Class.forName(sc.getInitParameter("driver_class"));
			String url=sc.getInitParameter("url");
			String user=sc.getInitParameter("user");
			String pass=sc.getInitParameter("password");
			Connection con=DriverManager.getConnection(url,user,pass);
			System.out.println("db connected");
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		
		
		ServletConfig g=getServletConfig();
		
		
		if (username.equals(g.getInitParameter("username")) && password.equals(g.getInitParameter("password")))	//when ever the admin changs then change it here but we don't want to change here
		
		{
			//RequestDispatcher rd = request.getRequestDispatcher("https://www.google.com/");
			//rd.forward(request, response);
			
			response.sendRedirect("welcome.jsp");	//for sending request outside the application to google and send redirect does not work with dopost() method
			

		} else {

			out.println("<b> user not registered yet. plz register now.</b>");
			RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
			rd.include(request, response);

		}

	}

}
