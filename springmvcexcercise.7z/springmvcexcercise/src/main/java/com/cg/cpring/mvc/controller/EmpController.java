package com.cg.cpring.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.cpring.mvc.service.EmpService;
import com.ch.spring.mvc.bean.Employee;




@Controller
public class EmpController {
	
	@Autowired
	EmpService service;
	
	
	
	@RequestMapping(value="/getall",method=RequestMethod.GET)
	public ModelAndView getEmplo()
	{
		ModelAndView mv=new ModelAndView("showall");
		mv.addObject("emp", service.getEmployee());
		return mv;
	}
	
	
	@RequestMapping(value="/adde",method=RequestMethod.GET)
	public ModelAndView addEmplo()
	{
		ModelAndView mv=new ModelAndView("add");
		mv.addObject("command", new Employee());  		//we use command here for binding the spring form values to a product object
		return mv;
		
	}


	@RequestMapping(value="/addemp",method=RequestMethod.POST)
	public String add(Employee p)
	{
	service.add(p);
	return "redirect:/getall";
	
	}

	
	
	@RequestMapping(value="/search",method=RequestMethod.GET)
	public ModelAndView searchEmployee(@RequestParam("id") int id)
	{
		ModelAndView mv=new ModelAndView("searchEmployee");
		mv.addObject("comm",service.searchById(id));
		return mv;
		
	}
	
	
	@RequestMapping(value="/upe",method=RequestMethod.GET)
	public ModelAndView updateEmployee(@RequestParam("id") int id)
	{
		ModelAndView mv=new ModelAndView("updateEmployee");
		mv.addObject("comm",service.updateById(id));
		return mv;
		
	}
	
	@RequestMapping(value="/dele",method=RequestMethod.GET)
	public String deleteEmployee(@RequestParam("id") int id)
	{
		service.deleteById(id);
		return "redirect:/getall";
		
		
	}
	
	

}
