package Lab_7;
import java.util.*;

public class ArayListAgain 
{
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		ArrayList<String> al=new ArrayList<String>(); 
		System.out.println("enter input");
		al.add(sc.next());   //EGG
		al.add(sc.next());		//APPLE
		al.add(sc.next());		//HONEY
		al.add(sc.next());	//MILK
		Collections.sort(al); 
		System.out.println("after soting:");
		for(String a:al)
		{
			
			System.out.println(a);
		}
		
	}
}
