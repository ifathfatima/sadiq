package Lab_8;					//8.3 2nd/3rd prog   correct prog but the output in file is not in prpoer format

import Lab_8.Employee.*;

import java.io.*;
import java.util.*;



 class Service implements Serializable
{
		
	
	public void  add() throws IOException,ClassNotFoundException
	{
	 
		 Employee e=new Employee(101,"ifath",20000l,"engineer");
		 
		 FileOutputStream fo= new FileOutputStream("D:\\filii.txt");
			ObjectOutputStream oos=new ObjectOutputStream(fo);
			oos.writeObject(e);
			
			
			FileInputStream fis=new FileInputStream("D:\\filii.txt");
			ObjectInputStream ois=new ObjectInputStream(fis);
			Employee ef1=(Employee)ois.readObject();
			System.out.println("id:"+ef1.id);
			System.out.println("name:"+ef1.name);
			
			System.out.println("salary:"+ef1.salary);
			
			System.out.println("desig:"+ef1.desig);
			
			
	 }
		 
	 public  void getName()
		{
			 
			System.out.println("name is:"+Employee.name);
			
		}
		
		 public void methodi(long salary,String desig)
		{
			if(salary<10000 && desig=="associate")
			{
				System.out.println("your insurance service is: GOLD");
				Employee.insuscheme="GOLD";
			}
			else if(salary<=20000 && desig=="engineer")
			{
		
				System.out.println("your insurance service is :diamond");
				Employee.insuscheme="DIAMOND";
			}
			else
			{
				System.out.println("your service is:PLATINUM");
				Employee.insuscheme="PLATINUM";
			}
				
		}
		 public void getId()
		 {
			 System.out.println("emp id is:"+Employee.id);
		 }
		 public void getSalary()
		 {
			 System.out.println("sal is :"+Employee.salary);
			 		
		 }
		 
		 public void display()
		 {
			 System.out.println("id id:"+Employee.id);
			 System.out.println("name is:"+Employee.name);
			 System.out.println("sal is:"+Employee.salary);
			 System.out.println("designation is:"+Employee.desig);
			 System.out.println("insurance scheme is:"+Employee.insuscheme);
			 
		 }
		 
		
}
