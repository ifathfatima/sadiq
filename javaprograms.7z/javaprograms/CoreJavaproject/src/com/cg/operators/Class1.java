package com.cg.operators;

public class Class1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i1=12, i2=4;
		int sum=i1+i2;
		System.out.println("sum is:"+sum);
		int dif=i1-i2;
		System.out.println("difference is:"+dif);
		int mul=i1*i2;
		System.out.println("multiplication  is:"+mul);
		int div=i1/i2;
		System.out.println("division  is:"+div);
		int modi=i1%i2;
		System.out.println("modulus  is:"+modi);
		
	}

}
