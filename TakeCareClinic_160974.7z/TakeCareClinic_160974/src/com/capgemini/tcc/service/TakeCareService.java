package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.Patient;
import com.capgemini.tcc.exception.TakeCareException;


public interface TakeCareService {
	public int addPatientDetails(Patient p) throws  TakeCareException;
	public Patient searchPatientDetails(int id) throws  TakeCareException;
	public boolean validateDetails(Patient p) throws  TakeCareException;
}
