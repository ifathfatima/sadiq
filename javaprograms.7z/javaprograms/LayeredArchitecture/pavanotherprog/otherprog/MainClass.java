package otherprog;
import java.util.Scanner;
import  otherprog.Validate.*;


public class MainClass 
{

	public static void main(String[] args)
	{
		Validate v=new Validate();
		Scanner sc= new Scanner(System.in);
		System.out.println("enter employee details");
		
		System.out.println("enter name");
		String name=sc.nextLine();
		//v.isName(name);
		if(v.isName(name)==false)
		{
			System.out.println("enter valid name");
		}
		
		

	}

}
