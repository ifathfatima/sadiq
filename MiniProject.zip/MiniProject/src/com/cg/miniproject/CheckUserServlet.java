package com.cg.miniproject;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.miniproject.dao.UserDao;

/**
 * Servlet implementation class CheckUserServlet
 */
@WebServlet("/CheckUserServlet")
public class CheckUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		String user=request.getParameter("user");

		String password=request.getParameter("pass");

		UserDao dao= new UserDao();

		
		boolean flag= dao.validateUser(user);
		
		
		if(flag)

		{
			
			//out.println("<b style='color:green;'>the user is valid but now cheak whether he is student or librarian");
		RequestDispatcher rd = request.getRequestDispatcher("check.jsp?useri="+user+"&&passwordi="+password);

		rd.include(request, response);

		}

		else

		{
			
			out.println("sorry the user is not present in D.B");
		RequestDispatcher rd = request.getRequestDispatcher("userlogin.jsp");

		rd.include(request, response);

		}
		
		
		
		
	}

}
