package com.cg.cpring.mvc.repository;

import java.util.List;


import org.springframework.stereotype.Repository;


import com.ch.spring.mvc.bean.Employee;


@Repository
public interface EmpRepo {
	
	
	List<Employee> getEmployee();
	
	
	void add(Employee e);
	
	Employee searchById(int id);
	
	Employee updateById(int id,double salary);
	
	void  deleteById(int id);
	
	

}
