package SirClassprog;
import java.util.*;

public class Priority 
{
	void display()
	{
	PriorityQueue<String>  q=new PriorityQueue<String>();
	
	}
	
	

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub

	}

}
