package Lab_8;					//8.3 1st/3 part     correct prog but the output in file is not in prpoer format
import java.util.*;
import java.io.*;

public class Employee implements Serializable
{
	 public static   int id;
		public  static	String name;
			public static long salary;
		public 	static String desig;
			 public  static String insuscheme;
		

		 public  Employee(int d, String n,long s, String desi)
		{
			id=d;
			name=n;
			salary=s;
			desig=desi;
			
		}
}
