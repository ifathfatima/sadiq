package SirClassprog;

public class Hello extends Thread{

	
	public synchronized void run()
	{
		
		System.out.println(Thread.currentThread().getName());
		 
		 System.out.println(Thread.currentThread().getPriority());
		System.out.println("hellO");
		//System.out.println(""+t.getName());
	}
	/*public void display()
	{
		System.out.println("me");
		Thread t=new Thread();
		System.out.println(""+t.getName());
	}
	*/
	
}
