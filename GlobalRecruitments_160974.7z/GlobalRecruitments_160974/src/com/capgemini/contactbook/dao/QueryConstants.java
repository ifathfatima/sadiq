package com.capgemini.contactbook.dao;

public class QueryConstants {

	public static final String insertQuery = "insert into enquiry values(enquiries.nextval,?,?,?,?,?)"; // to
																										// insert
																										// values
																										// into
																										// database

	public static final String getIdQuery = "select max(enqryid) from enquiry"; // once
																				// the
																				// data
																				// is
																				// inserted
																				// into
																				// database
																				// then
																				// generate
																				// the
																				// unique
																				// Id

	public static final String getDetails = "select * from enquiry where enqryid=?"; // for
																						// getting
																						// details
																						// from
																						// database

}
