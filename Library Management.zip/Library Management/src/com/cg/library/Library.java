package com.cg.library;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.TableGenerator;


@Entity

@TableGenerator(name="tab_seq", initialValue=1, allocationSize=1)  //generates a sequence for table in D.B
@NamedQuery(name="select_library",query="select l1 from Library l1")																//allocation size shows by how much to increment if not given then
																	//increments by default by 20
public class Library 
{
	
	@Id
	@GeneratedValue(strategy=GenerationType.TABLE, generator="tab_seq")
	private int  id;
	private String bookname;
	private double bookprice;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public double getBookprice() {
		return bookprice;
	}
	public void setBookprice(double bookprice) {
		this.bookprice = bookprice;
	}
	


}
