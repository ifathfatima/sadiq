package com.cg.miniproject;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.miniproject.dao.UserDao;

/**
 * Servlet implementation class DeleteBookInventoryServlet
 */
@WebServlet("/DeleteBookInventoryServlet")
public class DeleteBookInventoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String bookid = request.getParameter("bid");
		//String bookname = request.getParameter("bname");
		//String bookaurthor1 = request.getParameter("bauthor1");
		//String bookauthor2 = request.getParameter("bauthor2");
		//String publisher = request.getParameter("publisher");
		//String yearofpublish = request.getParameter("year");
		
		//ServletContext sc=getServletContext();
		
		
		UserDao dao=new UserDao();
		int n=dao.deleteBook(bookid);
		
		
		if(n>0)
		{
			out.println("successfully deleted data from book inventory table in D.B");
			RequestDispatcher rd=request.getRequestDispatcher("librarianhomepage.jsp");
			rd.include(request,response);
			
			//response.sendRedirect("login.jsp");
		}
		
		else
		{
			out.println("<b style='color:red;'>something went wrong plz try to delete the book  again</b>");
			RequestDispatcher rd=request.getRequestDispatcher("bookinventory.jsp");
			rd.include(request, response);

			
			//response.sendRedirect("register.jsp?emsg=something went wrong.register again. ");
		}

	}

}
