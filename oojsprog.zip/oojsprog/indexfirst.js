/*
let firstname;
let lastname;
let customer=
{

	display()
	{
			alert("this is customer class method");
	}
}
customer.display();	
//another way defining userdefined class 

function User()
{}
User.prototype.sayHello=()=>{
	alert("this is user method without parameters");
	}
	var u=new User();
	u.sayHello();
	
	*/
///////////////////////////////
//(correct)
/*
let fname=('ifath');
let lname=('sadiq');
let student={
	display()
	{
			alert("firstname:"+fname+"last name:"+lname);
	}
	}
	student.display();

*/
////////////////////////////////////////////////
//(correct)	
function student(){}  
student.prototype.fname;
student.prototype.lname;
	
student.prototype.display=(fname,lname)=>
	{
		alert("fisratname is:"+fname+"lastname is:"+lname);
	
	}
	var s=new student();
	
	s.display("ifath","sadiq");


