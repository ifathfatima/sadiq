package com.cg.library;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PersistPerson {

	public static void main(String[] args) {
		
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("Library Management");
		EntityManager em=factory.createEntityManager();
		em.getTransaction().begin();
		
		/*  has-a relationship
		Address a=new Address();
		a.setCity("golconda");
		a.setState("ts");
		*/
		
		
		Employee e1=new Employee(102,"hashu",5000.00);
		em.persist(e1);
		
		
		
		/*  has-a relationship
		p.getAddress().add(a);
		*/
		
		
		em.getTransaction().commit();
	}

}
