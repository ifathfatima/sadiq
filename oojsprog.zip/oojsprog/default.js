let fname;
let lname;


let user={
	
	set firstname(name)
	{
	this.fname=name;
	},
	set lastname(name)
	{
	this.lname=name;
	},
	
	
	
	get fullname(){
	return this.fname+"  "+this.lname;
	},
	
	get firstname()
	{
	return this.fname;
	
	},
	get lastname()
	{
	return this.lname;
	}
}

//calling setter method
user.firstname="ifath";
user.lastname="fatima";
//document.write(user.fullname);
document.write(user.firstname);
document.write("\n");

document.write(user.lastname);

