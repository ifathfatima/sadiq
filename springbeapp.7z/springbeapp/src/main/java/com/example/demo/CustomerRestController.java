package com.example.demo;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class CustomerRestController 
{
	
	
	@Autowired
	ICustomerService service;
	
	
	
	@RequestMapping(value="/getall",method=RequestMethod.GET)  //as we are not sending post object from front end so it is always GET only
	public List<Customer> getAllCus()
	{
		return service.getAll();
		
	}
	

	/*@RequestMapping(value="/getbyid/{id}",method=RequestMethod.GET)
	public Customer getAllCusbyId(@PathVariable("id") Integer id)
	{
		return service.getCusById(id);
		 
	}*/
	
	
	@RequestMapping(value="/add",method=RequestMethod.POST)   //as we are returning post object from front end
	public String  addCustomer(@RequestBody Customer c)		//this annotation as we sending an object
	{
		service.addCustomer(c);
		return "customer addes successfully to D.B";
		 
	}
	
	
	
	@RequestMapping(value="/delete")
	public String  deletById(@RequestBody Integer id)
	{
		 service.deleteById(id);
		 return "customer delete successfully from D.B";
		 
	}
	
	
	@RequestMapping(value="/update")  
	public String  updateCustomer(@RequestBody Customer c)		
	{
		service.updateCustomer(c);
		return "customer addes successfully to D.B";
		 
	}
	
	
	
	

}
