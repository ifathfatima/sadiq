package com.cg.mmobile.dao;

import com.cg.mobile.service.IMobileService;
import com.cg.mobile.service.MobileServiceImpl;


	public class QueryConstants 
	{
		
		
		public static final String insertQuery = "insert into purchasedetails values(id_seq.nextval,?,?,?,changeDate(date),?)";		//already the id is being genenrated here
		public static final String checkIdQuery = "select quantity from mobiles where mobileid=?";
		public static final String getId = "select max(PURCHASEID) from purchasedetails";		//here we use max(id) so that we need to enter a new row into table whose id is already generated in insert query
		public static final String updateQuery = "update mobiles set quantity=quantity-? where mobileid=?";
	}


