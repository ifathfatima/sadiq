package com.cg.eis.service;					//5.1 prog 3rd
import com.cg.eis.bean.*;
import com.cg.eis.exception.*;
import com.cg.eis.pl.*;

public class EmpMain  {

	
	public static void main(String[] args) {
		
		Employee e1= new Employee(101,"ifath",20000l,"engineer");
		
		Employee e2= new Employee(102,"hashu",2000l,"associate");
		Service s= new Service();
		s.methodi(20000l,"engineer");
		s.display();
		try
		{
			if(Employee.salary<3000)
				throw new EmpException();
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		

	}

}
