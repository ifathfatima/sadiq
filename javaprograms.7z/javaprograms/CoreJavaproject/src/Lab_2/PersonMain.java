package Lab_2;                     //2.3 half prog


public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person p= new Person();
		Person p1=new Person("mani","shah",'f');
		p.display();
		p1.display();
		
		

	}

}
