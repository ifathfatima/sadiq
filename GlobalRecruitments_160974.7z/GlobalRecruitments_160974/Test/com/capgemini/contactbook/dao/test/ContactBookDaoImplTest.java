package com.capgemini.contactbook.dao.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoImplTest {	//for testing the methods
	
	

	
	ContactBookDao dao = null;

	@Before
	public void setUp() {
		dao = new ContactBookDaoImpl();
	}

	@After
	public void tearDown() {
		dao = null;
	}

	@Test
	public void setDetailstest() 
	{

		EnquiryBean eb1 = new EnquiryBean();
		eb1.setContactNo("9090909987");
		eb1.setpDomain("Javaa");
		eb1.setfName("Ravikumar");
		eb1.setlName("noramandi");
		eb1.setpLocation("Hyderabad");
		
		
		try {
			

			Integer id = dao.addEnquiry(eb1);
			assertNotNull(id);

		} catch (ContactBookException e) {
			e.printStackTrace();
		}

	}
	
	@Test
	public void getDetailstDetailstest() {

		EnquiryBean eb2 = new EnquiryBean();
		try {
			eb2=dao.getEnquiryDetails(1005);
		} catch (ContactBookException e1) {
			
			e1.printStackTrace();
		}
		
		assertEquals("Ravikumar", eb2.getfName());
	}
		


}
