package com.cg.miniproject.dao.test;


import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


import com.cg.miniproject.Bean.*;
import com.cg.miniproject.dao.*;





public class MiniprojectDaoTest {
	
	
	
	UserDao dao = null;

	@Before
	public void setUp() {
		dao = new UserDao();
	}

	@After
	public void tearDown() {
		dao = null;
	}

	@Test
	public void checkUserStstusTest() 
	{

		UserBean ub = new UserBean();
		ub.setUserid("1");
		ub.setUsername("ifath");
		ub.setPassword("123");
		ub.setEmail("ifath@gmail.com");
		ub.setLibrarian("true");
		
		
		try {
			String s1=dao.getUserStatus(ub.getUsername());

			
			assertEquals("true",s1);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	
	


}
