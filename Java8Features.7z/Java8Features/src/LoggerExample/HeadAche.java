package LoggerExample;

import org.apache.log4j.Logger;

public class HeadAche 
{

	public static void main(String[] args) 
	{
		
	 	 Logger log=Logger.getLogger(HeadAche.class.getName());
	 	 log.error("hello");			//here the log file application will be generated in D drive
	}

}
