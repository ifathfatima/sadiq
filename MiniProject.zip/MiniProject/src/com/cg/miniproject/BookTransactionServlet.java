package com.cg.miniproject;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.miniproject.dao.UserDao;

/**
 * Servlet implementation class BookTransactionServlet
 */
@WebServlet("/BookTransactionServlet")
public class BookTransactionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		response.setContentType("text/heml");
		PrintWriter out=response.getWriter();
		String transactionid=request.getParameter("tid");
		String registrationid=request.getParameter("rid");
		
		String returndate=request.getParameter("returndate");
		UserDao dao=new UserDao();
		int n=dao.addTransaction(transactionid,registrationid,returndate);
		
		
		if(n>0){
		out.println("<b style='color:green'>Succefully added the book transaction details</b>");
		RequestDispatcher rs=request.getRequestDispatcher("librarianhomepage.jsp");
		rs.include(request, response);
		}
		else{
		out.println("<b style='color:red'>Something went wrong.Please try again to add trasaction details</b>");
		RequestDispatcher rs=request.getRequestDispatcher("booktransaction.jsp");
		rs.include(request, response);
		}
		
		
		
		
	}

}
