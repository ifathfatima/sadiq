package com.cg.javaObj;

public class Account 
{
	int bal=10000;
	int wit;
	void balance()
	{
		System.out.println("current balance is:"+bal);
	}
	void deposit(int d)
	{
		bal= bal+d;
		
		System.out.println("the avail balance is "+bal);
	}
	void withdraw(int wit)
	{
		System.out.println("the withdrwan balance is :"+wit);
		bal= bal-wit;
		System.out.println("the avail balance is:"+bal);
		
	}
	
	void checkBalance()
	{
		System.out.println("latest  balance is:"+bal);
	}
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
			Account a= new Account();
			a.balance();
			a.deposit(5000);
			a.withdraw(5000);
			a.checkBalance();
			
	}

}
