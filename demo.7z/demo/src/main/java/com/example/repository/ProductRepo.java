package com.example.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.example.bean.Product;

@Component
public class ProductRepo implements IProductRepo {

	List<Product> list = new ArrayList();

	public List<Product> getAllProduct() {
		// not needed when we ar using add.jsp
		Product p1 = new Product();
		p1.setId(list.size() + 1);
		p1.setName("android 6s");
		p1.setPrice(98000);
		list.add(p1);

		Product p2 = new Product();
		p2.setId(list.size() + 1);
		p2.setName("samsuing galaxy s4");
		p2.setPrice(80000);
		list.add(p2);

		Product p3 = new Product();
		p3.setId(list.size() + 1);
		p3.setName("windows s4");
		p3.setPrice(80000);
		list.add(p3);

		return list;
	}

	public Product getProductById(int id) {

		for (Product p : list) {
			if (p.getId() == id) {
				return p;

			}
		}

		return null;
	}

	
	
	
	public List<Product> delete(int id)
	{
		for (Product p : list)
		{
			if (p.getId() == id) 
			{
				list.remove(p);
				return list;
				

			}
		}

		return null;
		
	}
	
	
	public String addProduct(String name,double price) {
		
		Product p=new Product();
		p.setId(list.size()+1);
		p.setName(name);
		p.setPrice(price);
		list.add(p);
		return "product added to list";
		//adding the product 
		
	}
	
	
	
public String updateProduct(int id,String name,double price) {
		
	
	for (Product p : list)
	{
		if (p.getId() == id) 
		{
			p.setName(name);
			p.setPrice(price);
			
			return "product updates in  list";
			//adding the product 

		}
	}
	return null;

		
		
		
		
	}

}
