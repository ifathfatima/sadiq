package com.cg.spring.mvc.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cg.spring.mvc.bean.Product;

@Component
public class ProductRepoImpl  implements IProductRepo{
	
	
	List<Product> list=new ArrayList();
	

	public List<Product> getAllProduct() {
		/* not needed when we ar using add.jsp 
		Product p1=new Product();
		p1.setId(list.size()+1);
		p1.setName("android 6s");
		p1.setPrice(98000);
		list.add(p1);
		
		
		Product p2=new Product();
		p2.setId(list.size()+1);
		p2.setName("samsuing galaxy s4");
		p2.setPrice(80000);
		list.add(p2);
		
		
		
		Product p3=new Product();
		p3.setId(list.size()+1);
		p3.setName("windows s4");
		p3.setPrice(80000);
		list.add(p3);
		*/
		return list;
	}


	public void add(Product p) {
	
		Product p1=new Product();
		p1.setId(list.size()+1);
		p1.setName("android 6s");
		p1.setPrice(98000);
		list.add(p1);
		
		
		Product p2=new Product();
		p2.setId(list.size()+1);
		p2.setName("samsuing galaxy s4");
		p2.setPrice(80000);
		list.add(p2);
		
		
		
		Product p3=new Product();
		p3.setId(list.size()+1);
		p3.setName("windows s4");
		p3.setPrice(80000);
		list.add(p3);
		
		p.setId(list.size()+1);
		list.add(p);  //adding the product 
		
	}


	public Product searchById(int id) 
	{
		
		
		
		
		for(Product p:list)
		{
			if(p.getId()==id)
			{
				return p;
				
			}
		}
		
		
		return null;
	}

}
