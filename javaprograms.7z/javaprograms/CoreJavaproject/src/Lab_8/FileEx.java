package Lab_8;						//8.1 program not working
import java.io.*;
import java.util.*;


public class FileEx 
{

	public static void main(String[] args)
	{
		try
		{
			FileReader fr= new FileReader("D:\\abc.txt");
			FileWriter fw=new FileWriter("D:\\bcd.txt");    		//donot create this file the vprog will create on its own
			BufferedReader br = new BufferedReader(fr);  
			
			 ArrayList li = new ArrayList();
		      String line;
		      while ((line = br.readLine()) != null) {
		        li.add(line);
		      }
		      br.close();

		      Collections.reverse(li);
		      System.out.println(li);
		      Iterator i = li.iterator();
		      
		      
		    while(i.hasNext()) 
		      {
		        fw.write((String)i.next());
		      }
		     fw.close();
			
			
		}
		
        
		catch(IOException e)
		{
			System.out.println(e);
		}
		    
		

		
		
	}

}
