package com.cg.operators;

public class logical {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int x=2,y=3,z=1;
		//System.out.println((x>y)&&(x>z));
		//System.out.println((x>y)||(x>z));
		//boolean p=true, q=false;
		//System.out.println(p&q);
		//System.out.println(p|q);
		//System.out.println(p^q);
		//System.out.println(!p);
		//System.out.println(p&&q);
		System.out.println(y&x);
		
		
		
	}

}
