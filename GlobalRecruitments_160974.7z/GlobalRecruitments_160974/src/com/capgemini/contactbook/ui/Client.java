package com.capgemini.contactbook.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import com.igate.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.*;

public class Client {
	static Logger logger = Logger.getLogger(Client.class); // included so that
															// the log messages
															// can be loaded in
															// log file

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		logger.info("log4j file loaded...");
		logger.info("inside main method");

		ContactBookService service = new ContactBookServiceImpl(); // an object
																	// of
																	// ContactBookServiceImpl
																	// class is
																	// created

		Scanner scanner = new Scanner(System.in);

		// patientService service = new patientServiceImpl();
		System.out.println("***********Global Recruitments**********");
		while (true)

		{

			System.out.println("Choose your operation");

			System.out.println("1. Enter enquiry details");
			System.out.println("2. view enquiry details on ID");
			System.out.println("0. EXIT");
			System.out.println("***************");
			System.out.println("Please enter a choice:");
			System.out.println("***************************");

			int option = 0; // asking input from user
			try {
				option = scanner.nextInt();
			} catch (InputMismatchException e) {
				System.err.println("Enter only digits 1 or 2 or 0:"); // the input entered
															// should only be
															// digits
			}

			switch (option) {

			case 1: // asking the user to enter the details
				scanner.nextLine();
				EnquiryBean eb = new EnquiryBean();

				System.out.println("Enter First Name:");
				String fname = scanner.nextLine();
				eb.setfName(fname);

				System.out.println("Enter Last Name:");

				String lname = scanner.nextLine();
				eb.setlName(lname);

				System.out.println("Enter Contact Number:");
				String contactno = scanner.nextLine();

				eb.setContactNo(contactno);
				System.out.println("Enter Preferred Domain:");
				String pdomain = scanner.nextLine();
				eb.setpDomain(pdomain);

				System.out.println("Enter Prefered Location");
				String plocation = scanner.nextLine();

				eb.setpLocation(plocation);

				try {

					boolean result = service.isValidEnquiry(eb); // if all
																	// validations
																	// a re true
																	// then
																	// enter the
																	// values in
																	// database

					if (result) {
						int id = service.addEnquiry(eb);
						
						System.out.println("****************************");
						System.out.println("\n");
						
						System.out.println("Thank you " + eb.getfName() + " "
								+ eb.getlName() + " " + "your Unique id is"
								+ " " + id + " "
								+ "we will contact you shortly");
						System.out.println("****************************");
					}

				} catch (ContactBookException e) {
					System.err.println(e.getMessage());
				}

				break;
			case 2: // user enters the id for which he wants to see output
				System.out.println("Enter the Enquiry No");
				int id = 0;
				try {
					id = scanner.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("enter only digits");
				}

				EnquiryBean eb1;
				try {
					eb1 = service.getEnquiryDetails(id);
					// System.out.println(eb1);
					eb1.display(); // displaying the details to user

				} catch (ContactBookException e) {

					System.err.println(e.getMessage());
				}
				break;
			case 0:
				System.out.println("Thank you for selecting us!!");
				System.exit(0); // for exiting from Global recruitments software
				break;

			default:
				break;
			}

		}

	}

}
