package Lab_2;                        //2.1 prog

public class PersonalDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String fi="divya";
		String la="bhrathi";
		char ge='F';
		int ad=20;
		double wt=85.55;
		System.out.println("personal details:");
		System.out.println("-------------------");
		
		System.out.println("First name:"+fi);
		System.out.println("last name:"+la);
		
		System.out.println("gender:"+ge);
		System.out.println("age"+ad);
		
		System.out.println("weight:"+wt);
		
		

	}

}
