package com.cg.spring.core;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployee {

	public static void main(String[] args) {
		
		//this container is used when we use destroy()
		ConfigurableApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		
		//as destroy() is not present in the below container
		
		
		
		
		
		
		
		//ApplicationContext  context=new ClassPathXmlApplicationContext("spring.xml");
		Employee e1=context.getBean(Employee.class);
		
		
		System.out.println(e1);
		
		
		/*
		//setting the data in spring.xml file ussing constructor type injection 
		e1.setId(123);
		e1.setName("ifath");
		e1.setSalary(10000);
		
		System.out.println(e1);
		*/
		
		
		Manager m1=context.getBean(Manager.class);
		
		
		System.out.println(m1);
		/*
	
		m1.setDeptno(10);
		m1.setProjectname("javabean");
		m1.setProjectcode("abc1");
		System.out.println(m1);
		*/
		
		context.close();
		
		
		
		

	}

}
