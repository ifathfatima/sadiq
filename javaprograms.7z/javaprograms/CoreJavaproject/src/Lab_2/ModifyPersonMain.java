package Lab_2;                         //2.4 half prog


public class ModifyPersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		ModifyPerson p= new ModifyPerson();
		ModifyPerson p1=new ModifyPerson("mani","shah",'f',9502098527l);
		p.display();
		
		p.displayp();
		p1.display();
		p1.displayp();
		
	}

}
