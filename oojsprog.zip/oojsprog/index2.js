//parameterised function

function User()
{}
User.prototype.sayHello=(message)=>{
	alert(message);
	}
	
	var u=new User();
	u.sayHello("hi i am");