package com.example.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.bean.Product;


@Repository
public interface IProductRepo {
	
	
	List<Product> getAllProduct();
	Product getProductById(int id);
	 List<Product> delete(int id);
	 String addProduct(String name,double price);
	 String updateProduct(int id,String name,double price);
	 
	

}
