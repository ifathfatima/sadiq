package com.capgemini.emp.ui;
import com.capgemini.emp.dao.*;
import com.capgemini.emp.service.*;

import java.util.*;
import com.capgemini.emp.bean.*;

 class Client
{ 
	public static void main(String args[])
	{
		Employee e=new Employee();
		EmployeeService es=new EmployeeService();
		System.out.println("1)enter employee details \n 2)Exit");
		Scanner sc=new Scanner(System.in);
		int opt=sc.nextInt();
		if(opt==1)
		{
			//Employee.setDetails();
			//Employee.getDetails();
			
			es.addEmployee(e);
			Employee e1=es.getEmployee(e.id);
			System.out.println("id is:"+e1.id);
			System.out.println("Enter the name of the Employee : "+e1.name);
			System.out.println("Enter Employee phone number: "+e1.ph);
			System.out.println("Enter role is: "+e1.rol);
			System.out.println("Salary:"+e1.sal);
			System.out.println("mail id:"+e1.mail);
			new EmployeeDao().getRol();
		
		}
		else
		{
			System.out.println("EXIT");
		}
		
		
		
		//Service s=new Service();
		
	}

}