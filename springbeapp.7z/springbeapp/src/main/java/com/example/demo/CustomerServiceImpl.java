package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerRepo repo;

	List<Customer> list = new ArrayList();

	@Override
	public List<Customer> getAll() {

		repo.findAll().forEach(list::add);

		return list;
	}

	/*
	 * public Customer getCusById(Integer id) {
	 * 
	 * 
	 * return repo.findOne(id);
	 * 
	 * }
	 */

	public void addCustomer(Customer c) {

		repo.save(c);

	}

	public void deleteById(Integer id) {

		repo.delete(id);

	}

	public void updateCustomer(Customer c)
	{
		Integer id1=c.getId();
		String name=c.getCname();
		String cityi=c.getCity();
		String mail=c.getMailid();
		
		Customer c1=repo.findOne(id1);
		c1.setMailid(mail);
		c1.setCity(cityi);
		repo.save(c1);
		
		
	}
}
