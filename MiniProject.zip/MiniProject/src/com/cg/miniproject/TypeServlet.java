package com.cg.miniproject;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.miniproject.dao.UserDao;

/**
 * Servlet implementation class TypeServlet
 */
@WebServlet("/TypeServlet")
public class TypeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out= response.getWriter();

		String user=request.getParameter("user");

		String password=request.getParameter("pass");

		UserDao dao= new UserDao();

		
		String u= dao.getUserStatus(user);

		

		if("true".equals(u))

		{

		RequestDispatcher rd = request.getRequestDispatcher("librarianhomepage.jsp");

		rd.include(request, response);

		}

		else

		{

		RequestDispatcher rd = request.getRequestDispatcher("student.jsp");

		rd.include(request, response);

		}
		
		
		
	}

}
