package com.capgemini.tcc.exception;

public class TakeCareException extends Exception{
	
	private String message;

	public TakeCareException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

}
