package com.cg.spring.javaconfig;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

public class Product {  
	
	
	
	private String productname;
	private double productprice;
	
	
	//private List<String> l1;
	
	private String sal;
	
	
	
	
	

	
	public String getSal() {
		return sal;
	}

	public void setSal(String sal) {
		this.sal = sal;
	}

	public Product()
	{
		
	}
	
	public Product(String productname, double productprice) {
		super();
		this.productname = productname;
		this.productprice = productprice;
	}

	

	


	
	
	public Product(String productname, double productprice, String sal) {
		super();
		this.productname = productname;
		this.productprice = productprice;
		this.sal = sal;
	}

	@Override
	public String toString() {
		return "Product [productname=" + productname + ", productprice=" + productprice + ", sal=" + sal + "]";
	}

	public String getProductname() {
		return productname;
	}



	public void setProductname(String productname) {
		this.productname = productname;
	}



	public double getProductprice() {
		return productprice;
	}



	public void setProductprice(double productprice) {
		this.productprice = productprice;
	}
	
	
	
	
	
}
