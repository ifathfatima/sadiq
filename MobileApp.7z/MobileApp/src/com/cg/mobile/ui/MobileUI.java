package com.cg.mobile.ui;

import java.time.LocalDate;
import java.util.*;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;
import com.cg.mobile.service.IMobileService;
import com.cg.mobile.service.MobileServiceImpl;
import com.exceptions.MobileException;

public class MobileUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		IMobileService service =new MobileServiceImpl();
		//System.out.println(service.display());
		
		
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("\n");
			System.out.println("Welcome to Mobile sale shop ");
			System.out.println("====================");
			System.out.println("1. insert and purchase details and  update the mobile quanitity");
			//System.out.println("2. update the mobile quanitity ");
			System.out.println("3. view details of all mobiles in shop");
			System.out.println("4. delete mobile details based on mobile id ");
			System.out.println("5.search for mobile based on price range");
			System.out.println("6. exit");
			System.out.println("enter your option");
			int opt=sc.nextInt();
			switch(opt)
			{
			case 1:
				sc.nextLine();		//if we dont use this then dont allow string val 
				System.out.println("Name:");
				String name = sc.nextLine();

				System.out.println("mobile id:");
				int mobile = 0;

				try {
					mobile = sc.nextInt();
				} catch (Exception e) {
					System.out.println("Enter only digits:");
					System.exit(0);
				}

				System.out.println("Quantity:");
				int quantitty = 0;

				try {
					quantitty = sc.nextInt();
				} catch (Exception e) {
					System.out.println("Enter only digits:");
				}
				System.out.println("enter date:");
				int yyyy=sc.nextInt();
				int mm=sc.nextInt();
				int dd=sc.nextInt();
				LocalDate date = LocalDate.of(yyyy,mm,dd);
				
				Customer customer = new Customer(name, mobile, quantitty,date);

				try {
					boolean resut = service.validateFileds(customer);  		///return true if all validatons are correct

					if (resut) {		//if all validations are true only then enter this loop
						int id;
						try {
							id = service.storeDetails(customer);
							System.out.println("id is: " + id);
							System.out.println("check database for changes");

						} catch (MobileException e) {
							System.out.println(e.getMessage());
						}
					}

				} catch (MobileException e1) {
					System.err.println(e1.getMessage());
				}

				// System.out.println("enter the date of purchase");
				 //no need to enter date becoz in query we give the sysdate
				// Date date=new SimpleDateFormat("dd/MM/yyyy").parse(sc.nextLine());
				
				
				break;
				
			//case 2:
				
				
				
				//break;
			case 3:
				
				List<Mobile> l1=service.getAllMobile();
				for(Mobile m:l1)
				{
				System.out.println("id:"+m.getMobileId());
				System.out.println("name:"+m.getName());
				System.out.println("price:"+m.getPrice());
				System.out.println("quantity:"+m.getQuantity());
				System.out.println("--------------------");
				}
				
				break;
			case 4:
				System.out.println("====================");
				System.out.println("enter id");
				int mobileId=sc.nextInt();
				/*List<Mobile> l2=service.getMobileByPrice(mobileId);
				for(Mobile m:l2)
				{
				System.out.println("id:"+m.getMobileId());
				System.out.println("name:"+m.getName());
				System.out.println("price:"+m.getPrice());
				System.out.println("quantity:"+m.getQuantity());
				System.out.println("--------------------");
				}
				System.out.println("row deleted from mobile table");
				*/
				System.out.println(service.deleteMobile(mobileId));
				System.out.println("\n");
				break;
			case 5:
				System.out.println("====================");
				System.out.println("enter price");
				double price=sc.nextDouble();
				List<Mobile> l=service.getMobileByPrice(price);
				for(Mobile m:l)
				{
				System.out.println("id:"+m.getMobileId());
				System.out.println("name:"+m.getName());
				System.out.println("price:"+m.getPrice());
				System.out.println("quantity:"+m.getQuantity());
				System.out.println("--------------------");
				}
				
				break;
			case 6:
				System.out.println("thank u");
				System.exit(0);
				break;
				
				
			
			}
			
		}
		
		
		
		
		/*Iterator it=l.
		while(m=(Mobile)l.hasNext())
		{
			
		}
		*/
		
		
		/*for(Mobile m:l)
		{
		System.out.println("id:"+m.getMobileId());
		System.out.println("name:"+m.getName());
		System.out.println("price:"+m.getPrice());
		System.out.println("quantity:"+m.getQuantity());
		System.out.println("--------------------");
		}
		*/
	}

}
