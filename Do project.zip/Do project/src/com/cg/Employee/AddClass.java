package com.cg.Employee;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



public class AddClass 
{


		public void add()
		{
			EntityManagerFactory emf2=Persistence.createEntityManagerFactory("Do project");
			EntityManager em2=emf2.createEntityManager();
			em2.getTransaction().begin();
			
			
			
			System.out.println("enter the details to enter into D.B");
			Scanner sc=new Scanner(System.in);
			
			//int id=sc.nextInt();
			Employee e1= new Employee();
			
			System.out.println("enter the name:");
			String name=sc.next();
			
			
			e1.setName(name);
			
			
			System.out.println("enter the salary:");
			
			double sal=sc.nextDouble();
			e1.setSalary(sal);
			
			
			em2.persist(e1);
			
			System.out.println("data inserted into D.B");
			
			
			em2.getTransaction().commit();
			em2.close();
			emf2.close();
			
		}
}
