package com.cg.spring.jpa.springdata.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.spring.jpa.springdata.bean.Product;

@Repository
public interface IProductRepo {
	
	
	public List<Product> getAllProduct();
	public Product geProduct(int id);
	
	public	List<Product> getProductByName(String name);
	
	
	public void addProduct(int id,String name,double price);
	public void updatProduct(int id,String name,double price);
	public void deletProduct(int id);
	
	
	

}
