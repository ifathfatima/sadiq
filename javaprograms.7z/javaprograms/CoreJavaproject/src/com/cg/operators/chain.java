package com.cg.operators;

public class chain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,c;
		a=b=c=100;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		

	}

}
