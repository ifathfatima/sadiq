package com.cg.simplexmlcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.simplexmlcore.Employee;



public class TestEmployee {

	public static void main(String[] args) {
		

		ApplicationContext c=new ClassPathXmlApplicationContext("spring.xml");
		Employee e1=c.get

		

		
	}

}
