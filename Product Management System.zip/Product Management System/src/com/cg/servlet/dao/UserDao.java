package com.cg.servlet.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class UserDao {

	Connection con = null;
	//Statement s=null;
	PreparedStatement ps = null;

	public Connection getConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String user = "system";
			String pass = "Capgemini123";
			con = DriverManager.getConnection(url, user, pass);
			return con;

		} catch (Exception e) {

			e.printStackTrace();

		}

		return con;

	}
	
	
	public boolean validateUser(String passwor)
	{
		con = getConnection();
		String sql = "select * from user_details where password=?";
		
		try{
			ps=con.prepareStatement(sql);
			ps.setString(1,passwor);
			
			
			ResultSet rs=ps.executeQuery();
			return rs.next();
			//String uname=rs.getString(1);
			
			
			
			
		}
		catch (Exception e) {

			return false;
		}
		
	}

	
	
	public int add(String username, String password, String mail, String mobile) // fields to user_details table
	// in
	// register.jsp
	// file
	{
		con = getConnection();
		String sql = "insert into user_details values(?,?,?,?)";

		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			ps.setString(3, mail);
			ps.setString(4, mobile);
			int n = ps.executeUpdate();
			return n;
		}

		catch (Exception e) {

			e.printStackTrace();
		}
		return 0;
	}
	public int addProduct(String id, String  pname, String model, String price) // fields to product_details table
	// in
	// register.jsp
	// file
	{
		con = getConnection();
		String sql = "insert into product_details values(?,?,?,?)";

		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, id);
			ps.setString(2, pname);
			ps.setString(3, model);
			ps.setString(4, price);
			int n = ps.executeUpdate();
			return n;
		}

		catch (Exception e) {

			e.printStackTrace();
		}
		return 0;
	}
	
	public int editProduct(String id,String price)
	{
		con = getConnection();
		String sql = "update product_details  set p_price=? where p_id=?";

		try {
			ps = con.prepareStatement(sql);
			ps.setString(1,price);
			ps.setString(2,id);

			int n = ps.executeUpdate();
			return n;
		}

		catch (Exception e) {
			
			e.printStackTrace();
		}
		return 0;
	}
	
	public int deleteProduct(String id)
	{
		con = getConnection();
		String sql = "delete from product_details  where p_id=?";

		try {
			ps = con.prepareStatement(sql);
			
			ps.setString(1, id);

			int n = ps.executeUpdate();
			return n;
		}

		catch (Exception e) {

			e.printStackTrace();
		}
		return 0;
	}
	
	public int validatePassword(String phone)
	{
		
		con = getConnection();
		String sql = "select password from user_details  where mobile=?";

		try {
			ps = con.prepareStatement(sql);
			
			ps.setString(1, phone);

			int n = ps.executeUpdate();
			return n;
		}

		catch (Exception e) {

			e.printStackTrace();
		}
		return 0;

	}
	
	public int updatePassword(String phone,String newpassword)
	{
		con = getConnection();
		String sql = "update  user_details set password=? where mobile=?";

		try {
			ps = con.prepareStatement(sql);
			
			
			ps.setString(1, newpassword);
			ps.setString(2, phone);
			

			int n = ps.executeUpdate();
			return n;
		}

		catch (Exception e) {

			e.printStackTrace();
		}
		return 0;
	}
	
	
}
