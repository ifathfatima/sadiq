package Lab_8;					//8.3 prog full prog   but not correct sir gave Myclass7 and MyClass8 other 8.3 prog is aslo there

import java.util.*;


import java.io.*;



  class EnhanceFun implements Serializable
 {
	 	

		
	 public    	int id;
	 public 	String name;
	 public 	long salary;
	 public 	String desig;
	 public  	String insuscheme;
	 
	 public  EnhanceFun(int d, String n,long s, String desi)
		{
			id=d;
			name=n;
			salary=s;
			desig=desi;
			
		}
	 public void display()
	 {
		 System.out.println("id id:"+id);
		 System.out.println("name is:"+name);
		 System.out.println("sal is:"+salary);
		 System.out.println("designation is:"+desig);
		 //System.out.println("insurance scheme is:"+insuscheme);
		 
	 }
 }
public  class Service1 
 {
	 
	 public static void main(String[] args) throws IOException,ClassNotFoundException
	{
		 EnhanceFun ef=new EnhanceFun(101,"ifath",20000l,"analyst");
		 //ef.display();
		FileOutputStream fo= new FileOutputStream("D:\\fili.txt");
		ObjectOutputStream oos=new ObjectOutputStream(fo);
		oos.writeObject(ef);
		
		
		FileInputStream fis=new FileInputStream("D:\\fili.txt");
		ObjectInputStream ois=new ObjectInputStream(fis);
		EnhanceFun ef1=(EnhanceFun)ois.readObject();
		System.out.println("id:"+ef1.id);
		System.out.println("name:"+ef1.name);
		
		System.out.println("salary:"+ef1.salary);
		
		System.out.println("desig:"+ef1.desig);
	 
	}
	 
 }




















