package Lab_8;					//8.1 prog sir's verison correct output

import java.lang.*;
import java.io.*;
import java.util.*;

public class FileReverse2 
{

	public static void main(String[] args) 
	{
		try
		{
		FileReader fr= new FileReader("D:\\abc.txt");
		FileWriter fw=new FileWriter("D:\\bcd.txt");   
		Scanner s=new Scanner(fr);
		BufferedReader br=new BufferedReader(fr);
		StringBuilder sb=new StringBuilder();
		String or;
		while(s.hasNext())
		{
			or=s.nextLine();
			StringBuilder sb1=new StringBuilder(or);
			sb.append(sb1.reverse().toString()).append("\n");
		}
		System.out.println(sb.toString());
		
		fw.write(sb.toString());

		}
		catch(IOException e)
		{
			System.out.println(e);
		}

	
	}
}
