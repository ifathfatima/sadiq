package com.cg.core.spring.beans;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Customer {  //bean class
	
	private String firstname;
	
	private String lastname;
	
	private Address addr;
	
	
	//mapping of collections to bean class 
	
	List<Address> list;
	Set<String> s1;
	
	Map<Integer,Address> m1;
	
	
	
	

	public Map<Integer, Address> getM1() {
		return m1;
	}


	public void setM1(Map<Integer, Address> m1) {
		this.m1 = m1;
	}


	public Set<String> getS1() {
		return s1;
	}


	public void setS1(Set<String> s1) {
		this.s1 = s1;
	}


	public List<Address> getList() {
		return list;
	}


	public void setList(List<Address> list) {
		this.list = list;
	}


	public String getFirstname() {
		return firstname;
	}


	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}


	public String getLastname() {
		return lastname;
	}


	public void setLastname(String lastname) {
		this.lastname = lastname;
	}


	public Address getAddr() {
		return addr;
	}


	public void setAddr(Address addr) {
		this.addr = addr;
	}


	

	

	

	@Override
	public String toString() {
		return "Customer [firstname=" + firstname + ", lastname=" + lastname + ", addr=" + addr + ", list=" + list
				+ ", s1=" + s1 + ", m1=" + m1 + "]";
	}


	public Customer(String firstname, String lastname, Address addr) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.addr = addr;
	}
	
	public Customer(){}
	
	
	
}
