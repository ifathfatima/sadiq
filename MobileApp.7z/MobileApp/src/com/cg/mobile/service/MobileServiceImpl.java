package com.cg.mobile.service;

import java.sql.SQLData;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mmobile.dao.IMobileDao;
import com.cg.mmobile.dao.MobileDaoImpl;
import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;
import com.exceptions.MobileException;
public class MobileServiceImpl implements IMobileService {
	
	
	IMobileDao dao= new MobileDaoImpl();
	List<String> list = new ArrayList<String>();
	@Override
	public String display()
	{
		return dao.display();
	}
	@Override
	 public List<Mobile> getMobileByPrice(double price)
	 {
		return dao.getMobileByPrice(price);
		
	 }
	@Override
	public List<Mobile> getAllMobile()
	{
		return dao.getAllMobile();
	}
	
	@Override
	 public String deleteMobile(int mobileId)
	 {
		return dao.deleteMobile(mobileId);
		
	 }
	@Override
	public int storeDetails(Customer customer) throws MobileException {
		return dao.store(customer);
	}

	@Override
	public boolean validateFileds(Customer customer) throws MobileException {

		//System.out.println(" in service: "+customer);
		
		boolean flag = false;

		if (!validateMobileId(customer.getMobileId())) {
			list.add("mobile should be 4 digits");
		}
	
		if (!validateName(customer.getCname())) {
			list.add("name length 6 to 20");
		}

		if (!list.isEmpty()) {			//if some exception came then theya r stored in list 
			flag = false;	// as exception has occured and pattern did not match
			throw new MobileException(list + "");
		} else {
			flag = true;		//if pattern match for both mobileid and name
		}
		return flag;

	}

	public boolean validateMobileId(int mobileId)
	{
		String mobileRegEx = "[0-9]{4}";
		Pattern pattern = Pattern.compile(mobileRegEx);
		Matcher matcher = pattern.matcher(String.valueOf(mobileId));
		return matcher.matches();
	}
	
	public boolean validateName(String name)
	{
		String nameRegEx = "[a-zA-Z]{6,20}";			//use var as this only to understand wha t is what
		Pattern pattern = Pattern.compile(nameRegEx);
		Matcher matcher = pattern.matcher(name);
		return matcher.matches();
	}

	  @Override
	  public  java.sql.Date changeDate(LocalDate date)
	{
		
		  java.sql.Date sqlDate = java.sql.Date.valueOf( date );
         
        System.out.println("utilDate:" + date);
        System.out.println("sqlDate:" + sqlDate);
        return sqlDate;
        
       
	}
	
	
	}
