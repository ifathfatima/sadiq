package Lab_10;						//10.1 prog full correct
import java.util.*;  
import java.io.*;  
public class Prop
{

	public static void main(String[] args) throws Exception
	{
		
		
		  
		Properties p=new Properties();  
		p.setProperty("name","Ifath");  
		p.setProperty("email","ifath.fatima17@gmail.com");
		p.setProperty("phonno","9502098527");
		p.store(new FileWriter("D:\\PersonProps.properties"),"person details");  
		
		//a)
		FileReader fr= new FileReader("D:\\PersonProps.properties");
		Properties p1=new Properties();
		p1.load(fr);
		Set s=p1.entrySet();  
		  
		Iterator itr=s.iterator();  
		while(itr.hasNext())
		{  
		Map.Entry e=(Map.Entry)itr.next();  
		System.out.println(e.getKey()+" = "+e.getValue());  
		
		}
		
		
		
		//b)
		FileReader fr1= new FileReader("D:\\PersonProps.properties");
		Properties p2=new Properties();
		p2.load(fr1);
		
		System.out.println(p2.getProperty("name"));
		System.out.println(p2.getProperty("email"));
		System.out.println(p2.getProperty("phonno"));
		

	}

}
