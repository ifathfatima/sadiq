package com.dao;

public class QueryConstants {

	public static final String insertQuery = "insert into customer values(id_seq.nextval,?,?,?)";		//already the id is being genenrated here
	public static final String checkIdQuery = "select quantity from mobile_test where mobileid=?";
	public static final String getId = "select max(id) from customer";		//here we use max(id) so that we need to enter a new row into table whose id is already generated in insert query
	public static final String updateQuery = "update mobile_test set quantity=quantity-? where mobileid=?";
}
