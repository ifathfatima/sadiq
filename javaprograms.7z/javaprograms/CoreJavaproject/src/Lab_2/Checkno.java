package Lab_2;                      //2.2 prog
import java.util.*;


public class Checkno {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i;
		Scanner sc= new Scanner(System.in);
		System.out.println("enter the number");
		i=sc.nextInt();
		if(i>0)
		{
			System.out.println("the number is positive");
		}
		else
		{
			System.out.println("the number is negative");
		}
		
		

	}

}
