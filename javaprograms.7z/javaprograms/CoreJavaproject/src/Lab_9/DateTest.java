package Lab_9;    				//9.2   2/2 prog
import org.junit.*;

import static org.junit.Assert.*;


public class DateTest
{
	
	@Test 
	public void testsetdate()
	{
		Date d1= new Date(19,10,2000);
		assertEquals(19,d1.getDay());
		assertEquals(10,d1.getMonth());
		assertEquals(2000,d1.getYear());
		
	}

	
}
