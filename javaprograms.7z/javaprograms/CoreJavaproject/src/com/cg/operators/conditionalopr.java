package com.cg.operators;

public class conditionalopr {
public static void main(String args[])
{
	String out;
	int a=6,b=12;
	out=a==b?"yes":"no";
	System.out.println("ans is:"+out);
	
}
}
