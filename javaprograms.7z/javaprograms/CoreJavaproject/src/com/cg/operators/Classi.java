package com.cg.operators;

public class Classi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte bv=5;
		short sv=10;
		int iv=30;
		long lv=60;
		float fv=20;
		double dv=20.123;
		boolean bov=true;
		char ch='w';
		System.out.println(bv);
		System.out.println(sv);
		System.out.println(iv);
		System.out.println(lv);
		System.out.println(fv);
		System.out.println(dv);
		System.out.println(bov);
		System.out.println(ch);

		
		
		

	}

}
