package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlet.dao.UserDao;

/**
 * Servlet implementation class ForgotPassword
 */
@WebServlet("/ForgotPassword")
public class ForgotPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String phone = request.getParameter("phone");

		//String password = request.getParameter("password");
		//String cpassword = request.getParameter("cpassword");

		// ServletContext sc=getServletContext();
		
			UserDao dao = new UserDao(); // as we now connectin gto databse
											// using setvletcontext concept
			int n = dao.validatePassword(phone);

			if (n > 0) {
				out.println("the user is already present in D.B");
				RequestDispatcher rd = request.getRequestDispatcher("updatepassword.jsp");
				rd.include(request, response);

				// response.sendRedirect("login.jsp");
			}

			else {
				out.println("<b style='color:red;'>plz enter the correct mobile number</b>");
				RequestDispatcher rd = request.getRequestDispatcher("forgotpassword.jsp");
				rd.include(request, response);

				// response.sendRedirect("register.jsp?emsg=something went wrong.register again. ");
			}
		} 
	
	

}
