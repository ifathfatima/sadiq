package Lab_4;		
import java.util.*;//4.1 prog not all is covered asked in question

 class Account 
{
	
	static int accnum;
	double bal=500.00;
	String accholder;

	
	void setDeposit(int dep)
	{
		bal=bal+dep;
		System.out.println("the new bal is:"+bal);
		
		
	}
	
	
	void getWithdraw(int wit)
	{
			if((bal-wit)<500)
				System.out.println("can't withdraw as bal less than 500");
			else
			{
				bal=bal-wit;
				System.out.println("bal is:"+bal);
			}
		
	}
	
	 double getBalance()
	{
		return bal;
		
	}
	 
}


 class Person1 extends Account
{
	  String name;
	  float age;
	   
	   Person1(int acc,double b,String s,float ag)
	   {
		   accnum=acc;
			bal=b;
			accholder=s;
			age=ag;
			
		   
	   }
	   void display()
	   {
		   System.out.println(accnum);
	   }
	    
	  public static void main(String args[])
	  {
		  	Random r=new Random();
		  accnum=r.nextInt(999);
		 Person1 acc1= new Person1(accnum,2000.00d,"SMITH",40);
		 //accnum+=1;
		  Person1 acc2=new Person1(accnum,3000.00d,"kathy",45);
		  acc2.accnum=acc1.accnum+1;
		  acc2.display();
		  acc1.setDeposit(2000);
		  acc2.getWithdraw(2000);
		  acc1.getBalance();
		  acc2.getBalance();
		  System.out.println(acc1.toString());
		  System.out.println(acc2.toString());
		  acc1.display();
		 acc2.accnum=acc1.accnum+1;
		  acc2.display();
		 
	  }
 }
