package com.cg.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;



@Path("/hello")

public class HelloWorld {
	
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/saytext")
	public String sayHelloAsText()
	{
		return "hello";
		
	}
	@GET
	@Produces(MediaType.TEXT_HTML)
	@Path("/sayhtml")
	public String sayHelloAsHtml()
	{
		return "<h1> Hello</h1>";
		
	}
	
	
	
	@GET
	@Produces(MediaType.TEXT_HTML)
	@Path("/sayxml")
	public String sayHelloXml()
	{
		return "<?xml version='1.0'?><name>Capgemini</name>";
		
	}

}
