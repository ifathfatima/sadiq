package LoggerExample;

import org.apache.log4j.Logger;

public class HeadAche {

	public static void main(String[] args) {
		
	 	static Logger log=Logger.getLogger(HeadAche.class.getName());
	
	}

}
