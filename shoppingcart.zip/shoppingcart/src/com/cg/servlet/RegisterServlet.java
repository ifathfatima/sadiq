package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlet.dao.UserDao;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String username = request.getParameter("user");
		String password = request.getParameter("pass");
		String ph = request.getParameter("phno");
		String email = request.getParameter("mail");
		
		//ServletContext sc=getServletContext();
		
		
		UserDao dao=new UserDao();  //as we now connectin gto databse using setvletcontext concept
		int n=dao.add(username, password, email, ph);
		if(n>0)
		{
			out.println("successfully entered data into D.B");
			RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
			rd.include(request,response);
			
			//response.sendRedirect("login.jsp");
		}
		
		else
		{
			out.println("<b style='color:red;'>something went wrong register again</b>");
			RequestDispatcher rd=request.getRequestDispatcher("register.jsp");
			rd.include(request, response);

			
			//response.sendRedirect("register.jsp?emsg=something went wrong.register again. ");
		}

		/*out.println("<html>");
		out.println("<body bgcolor='pink'>");
		out.println("<p>Welcome Mr. " + username + "</p>");
		out.println("<p>you entered password is:" + password + "</p>"
				+ "yor phone number is" + ph);
		out.println("<p> Your entered contact number is:" + ph + "</p>");
		out.println("<p> Your entered main id is:" + email + "</p>");
		out.println("</body>");

		out.println("</html>");
		
		*/
		
		
		/*		
		out.println("<b> You have registered successfully. Login again</b>");
		RequestDispatcher rd1 = request.getRequestDispatcher("login.jsp");
		rd1.include(request, response);
		*/
	}

}
