package Lab_7;							//7.3 prog

import java.util.HashMap;
import java.util.*;

public  class EmpDemo 
{
		
	   public  int id;
	   	String name;
		   long salary;
	 	 String desig;
		    String insuscheme;
		  EmpDemo()
		 {
		 
		 }
		 public  EmpDemo(int d, String n,long s, String desi)
			{
				id=d;
				name=n;
				salary=s;
				desig=desi;
				
			}
		public static  HashMap<Integer,EmpDemo>  hm= new HashMap<Integer,EmpDemo>();
		 
		 public void addEmployee(EmpDemo he)
		 
		 {
			 
			 EmpDemo ep1= new EmpDemo(101,"ifath",10000l,"associate");
			 EmpDemo ep2=new EmpDemo(102,"mani",20000l,"engineer");
			 EmpDemo ep3= new EmpDemo(103,"hashu",50000l,"analyst");
			 hm.put(ep1.id,ep1);
			 hm.put(ep2.id,ep2);
			 hm.put(ep3.id,ep3);
		
		 }
		 
		 	public boolean deleteEmployee(Integer id)	
		 {
			
		 		
			 hm.remove(ep1.id);
			 return true;
			 
		 }
		
		 public static  void main(String args[])
		 {
			  EmpDemo emp=new EmpDemo();
			 
			 emp.addEmployee(emp);
			 
			 for(Map.Entry<Integer,EmpDemo> entry:hm.entrySet())
			 {  
				 
			        Integer key=entry.getKey();  
			        EmpDemo b1=entry.getValue();  
			       
			        System.out.println(key+" Details:");  
			        System.out.println(b1.id+" "+b1.name+" "+b1.salary+" "+b1.desig);   
			 }
			 
			 emp.deleteEmployee(103);
			 System.out.println("hash map content after removing data:");
			 for(Map.Entry<Integer,EmpDemo> entry:hm.entrySet())			//for displaying the hm data after removing
			 {  
				 
			        Integer key=entry.getKey();  
			        EmpDemo b1=entry.getValue();  
			       
			        System.out.println(key+" Details:");  
			        System.out.println(b1.id+" "+b1.name+" "+b1.salary+" "+b1.desig);   
			 }
			
		 }
		 
}
	 

	//	 public boolean deleteEmployee(int id)
		// {
			 
	//	 }
		 

		 


/*
public class EmpDemo {

	public static void main(String[] args)
	{
		Emp he=new Emp();
		 
		 hm.put("e1",new HashEmp(101,"ifath",10000l,"associate"));
		 hm.put("e2",new HashEmp(102,"mani",20000l,"engineer"));
		 hm.put("e3",new HashEmp(103,"hashu",50000l,"analyst"));
		
		public void addEmployee(Emp hm);
		 
		 public boolean deleteEmployee(int id)
		  
		
		 

	}

}
*/