package com.cg.mmobile.dao;


	public class QueryConstants 
	{

		public static final String insertQuery = "insert into purchasedetails values(id_seq.nextval,?,?,?,'23-12-1996',?)";		//already the id is being genenrated here
		public static final String checkIdQuery = "select quantity from mobiles where mobileid=?";
		public static final String getId = "select max(id) from purchasedetails ";		//here we use max(id) so that we need to enter a new row into table whose id is already generated in insert query
		public static final String updateQuery = "update mobiles set quantity=quantity-? where mobileid=?";
	}


