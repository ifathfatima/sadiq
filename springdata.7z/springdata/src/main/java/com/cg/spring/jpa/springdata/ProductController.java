package com.cg.spring.jpa.springdata;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.cg.spring.jpa.springdata.bean.Product;
import com.cg.spring.jpa.springdata.service.IProductService;

@RestController
@ComponentScan(basePackages="com.cg.spring.jpa.springdata")
public class ProductController {
	
	
	@Autowired
	IProductService service;
	
	
	@RequestMapping("/getall")
	public List<Product> getAllProduct()
	{
		return service.getAllProduct();
		
	}
	
	
	@RequestMapping("/get/{id}")
	public Product getProduct(@PathVariable("id") int id)
	{
		return service.geProduct(id);
		
	}
	
	
	@RequestMapping("/getby/{name}")
	public List<Product> getProductByName(@PathVariable("name") String  name)
	{
		return service.getProductByName(name);
		
	}
	
	
	
	@RequestMapping("/add/{id}/{name}/{price}")
	public String   addProduct(@PathVariable("id") int id,@PathVariable("name") String name,@PathVariable("price") double price)
	{
		 service.addProduct(id,name,price);
		 return "product added succcessfully in d.b";
		 
		
		
	}
	
	
	@RequestMapping("/update/{id}/{name}/{price}")
	public String   updateProduct(@PathVariable("id") int id,@PathVariable("name") String name,@PathVariable("price") double price)
	{
		 service.updatProduct(id,name,price);
		 return "product updated succcessfully in d.b";
		 
		
		
	}
	
	@RequestMapping("/delete/{id}")
	public String   deleteProduct(@PathVariable("id") int id)
	{
		 service.deletProduct(id);
		 return "product  succcessfully in d.b";
		 
		
		
	}
	
	

}
