package SirClassprog;

abstract class Abstract1
{
	abstract  void run();
	void brake()
	{
		System.out.println("brake methos");
	}
	static void speed()
	{
		System.out.println("speed methos");
	}
}

 class Bike extends Abstract1
 {
	 void run()
		{
			System.out.println("runn methos");
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
		
		Bike b= new Bike();
		b.run();
		b.brake();
		Abstract1.speed();
	}

}
