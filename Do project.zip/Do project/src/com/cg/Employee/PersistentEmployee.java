package com.cg.Employee;

import java.util.Scanner;

public class PersistentEmployee {

	public static void main(String[] args) {
		
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("****************Welcome********************");
		System.out.println("List of Operations:");
		System.out.println("1.add");
		System.out.println("2.update");
		System.out.println("3.delete");
		System.out.println("4.view");
		System.out.println("5.search by id");
		System.out.println("6.EXIT");
		

		System.out.println("enter the choice:");
		
		int opt=sc.nextInt();
		switch(opt)
		{
		case 1:
		AddClass ac=new AddClass();
		ac.add();
		
			break;
			
		case 2:
			
			UpdateClass pc=new UpdateClass();
			pc.update();
			
			
			break;
			
		case 3:
			DeleteClass dc=new DeleteClass();
			dc.deleteNow();
			
			break;
			
		case 4:
			
			ViewClass vc=new ViewClass();
			vc.viewNow();
			break;
			
			
		case 5:
			ViewByIdClass vbi=new ViewByIdClass();
			vbi.viewById();
			
			break;
			
			
		case 6:
			System.out.println("EXIT");
			System.exit(0);
		}
		

	}

}
