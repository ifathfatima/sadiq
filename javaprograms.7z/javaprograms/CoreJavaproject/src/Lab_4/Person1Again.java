package Lab_4;					//sir's 4.1 prog half

public class Person1Again 
{
	private String name;
    private float age;
    public String getName() {
         return name;
    }
    public void setName(String name) {
         this.name = name;
    }
    public float getAge() {
         return age;
    }
    public void setAge(float age) {
         this.age = age;
    }
   
}
