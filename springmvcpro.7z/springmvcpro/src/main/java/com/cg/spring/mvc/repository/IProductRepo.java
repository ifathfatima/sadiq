package com.cg.spring.mvc.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.spring.mvc.bean.Product;


//here give the @repository in interface 

@Repository
public interface IProductRepo {
	
	List<Product> getAllProduct();
	
	void add(Product p);
	
	Product searchById(int id);
	

}
