package Lab_9;								// 9.2.1    1/2 prog
import java.util.*;

import Lab_2.Person;

public class PersonAgain
{
	String fi,la;
	char g;
	
	/*
	PersonAgain()
	{
		fi="ifath";
		la="sadiq";
		g='f';
	}
	*/
	 public PersonAgain(String r,String s,char t)
	{
		fi=r;
		la=s;
		g=t;
		
	}
	
	
	void setFirstName(String fi)
	{
		this.fi=fi;
	}
	
	
	String getFirstName()
	{
		return fi;
	}
	
	void setLastName(String la)
	{
		this.la=la;
		
	}
	String getLastName()
	{
		return la;
	}
	void setGender(char g)
	{
		this.g=g;
	}
	
	
	char getGender()
	{
		return g;
	}
	void display()
	{
		
		System.out.println("personal details:");
		System.out.println("-------------------");
		
		System.out.println("First name:"+fi);
		System.out.println("last name:"+la);
		
		System.out.println("gender:"+g);
		System.out.println("\n");
		
		
	}
	
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		//PersonAgain p= new PersonAgain();
		PersonAgain p1=new PersonAgain("mani","shah",'f');
		//p.display();
		p1.display();
	
	}
	
}
