package com.cg.Employee;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class UpdateClass {
	
	public void update()
	{
		EntityManagerFactory emf2=Persistence.createEntityManagerFactory("Do project");
		EntityManager em2=emf2.createEntityManager();
		em2.getTransaction().begin();
		
		
		
		System.out.println("enter the id for which you want  to update");
		Scanner sc=new Scanner(System.in);
		
		
		Employee e2=em2.find(Employee.class, sc.nextInt());
		
		if(e2==null)
		{
			System.out.println("the employee is not there in D.B");
		}
		else
		{
			System.out.println("enter the new name for employee ");
			String name=sc.next();
			System.out.println("enter the new salary for employee");
			double price=sc.nextDouble();
			e2.setName(name);
			e2.setSalary(price);
			em2.persist(e2);
			
			System.out.println("updated the value in D.B");
		}
		
		
		
		em2.getTransaction().commit();
		em2.close();
		emf2.close();
		
	}

}
