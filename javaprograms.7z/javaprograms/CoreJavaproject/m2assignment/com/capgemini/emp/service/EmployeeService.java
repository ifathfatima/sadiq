package com.capgemini.emp.service;
import com.capgemini.emp.bean.*;
import java.util.*;


interface IEmployeeService 
{
	void  addEmployee (Employee emp);
	Employee getEmployee (int empId);

}

public  class EmployeeService implements IEmployeeService 
{
	public void addEmployee(Employee emp)
	{
		Scanner sc= new Scanner(System.in);
		
		emp.name =sc.next();
		//System.out.println("Enter the name of the Employee : "+name);
		emp.ph=sc.nextLong();
		//System.out.println("Enter Employee phone number: "+ph);
		emp.rol=sc.next();
		//System.out.println("Enter Employee phone number: "+ph);
		emp.sal=sc.nextDouble();
		
		//System.out.println("Salary:"+sal);
		emp.mail=sc.next();
		
		Random r=new Random();
	emp.id=r.nextInt(50)+1;
		//for setting id randomly
		
		
		//System.out.println("mail id:"+mail);
	}

	public Employee getEmployee (int Id)
	{
		/*System.out.println("id is:"+Employee.id);
		System.out.println("Enter the name of the Employee : "+Employee.name);
		System.out.println("Enter Employee phone number: "+Employee.ph);
		System.out.println("Enter role is: "+Employee.rol);
		System.out.println("Salary:"+Employee.sal);
		System.out.println("mail id:"+Employee.mail);
		*/
		Employee e1=new Employee();
		return e1;
	}
}
