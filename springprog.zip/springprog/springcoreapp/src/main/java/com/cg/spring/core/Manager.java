package com.cg.spring.core;

public class Manager {
	
	private int deptno;
	private String projectname;
	private String projectcode;
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	public String getProjectname() {
		return projectname;
	}
	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}
	public String getProjectcode() {
		return projectcode;
	}
	public void setProjectcode(String projectcode) {
		this.projectcode = projectcode;
	}
	
	
	
	@Override
	public String toString() {
		return "Manager [deptno=" + deptno + ", projectname=" + projectname
				+ ", projectcode=" + projectcode + "]";
	}
	//for setter type injection of ppt of bean class 
	//default constuctor is a must for this setter type injection method otherwise error comes.
	
	
	
	
	
	
	

}
