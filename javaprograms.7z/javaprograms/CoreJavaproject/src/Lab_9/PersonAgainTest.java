package Lab_9;          					//9.2.1   2/2 prog
import org.junit.*;
import static  org.junit.Assert.*;

public class PersonAgainTest 
{

	
		@Test
		public void testEverything()
		{
			PersonAgain p2=new PersonAgain("mani","shah",'f');
			assertEquals("mani",p2.getFirstName());
			assertEquals("shah",p2.getLastName());
			assertEquals('f',p2.getGender());
		}
		@Test
		public void testDisplay()
		{
			PersonAgain p3=new PersonAgain("ifath","sadiq",'f');
			
		}
}
