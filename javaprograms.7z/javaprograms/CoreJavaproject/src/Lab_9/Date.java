package Lab_9;						//9.2   1/2 prog
import java.util.*;
import java.lang.*;


public class Date 
{
	
	int intDay,Month,Year;
	// Constructor
	Date(int intDay, int intMonth, int intYear)  	
	{
		this.intDay = intDay;
		this.Month = intMonth;
		this.Year = intYear;
	}
	// setter and getter methods
	void setDay(int intDay)	
	{
		this.intDay = intDay;
	}
		int getDay( )		
	{
		return  this.intDay;
	}
	
	void setMonth(int intMonth)
	{
		this.Month = intMonth;
	}

	int getMonth( )
	{
		return  this.Month;
	}

	void setYear(int intYear)
	{
		this.Year=intYear;
	}



	int getYear( )
	{
		return  this.Year;
	}
	public String toString() //converts date obj to string.    
	{
		return	"Date is "+intDay+"/"+Month+"/"+Year; 
	}
	
	public static void main(String args[])
	{
		Date d= new Date(23,12,1996);
	String s=d.toString();
	System.out.println(s);
	}
	 // Date class

}
