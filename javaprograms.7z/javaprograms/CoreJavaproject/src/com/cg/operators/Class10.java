package com.cg.operators;

 class Company {
	 String k=" this is parent";
	 public void display()
	 {
		 System.out.println("hello");
	 }
}
 public  class Class10 extends Company
{
	public void check()
	{
		System.out.println("success"+k);
	}
	public   void view(Class10 c)
	{
			if(c instanceof Class10)
			{
					Class10 b1= (Class10) c;
					b1.check();
					System.out.println("success"+k);
			}
	}
	public static void main(String args[])
	{
		Class10 c=new Class10();
	c.view(c);
	c.display();
	
	
	} 
}
