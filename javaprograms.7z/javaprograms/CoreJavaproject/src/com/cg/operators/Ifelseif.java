package com.cg.operators;

public class Ifelseif {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=30,b=30;
		if(b>a){
			System.out.println("b is greater");
		}
		else if(a>b)
		{
			System.out.println("a is greater");
			
		}
		else
		{
			System.out.println("booth are equal");
			
		}
	}

}
