package com.cg.cpring.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cg.cpring.mvc.repository.EmpRepo;
import com.ch.spring.mvc.bean.Employee;


@Component
public class EmpServiceImpl implements EmpService {
	
	
	
	@Autowired
	EmpRepo repo;
	
	public List<Employee> getEmployee(){
		
		
		return repo.getEmployee();
		
		
	}
	
	
	public void add(Employee p) {
		repo.add(p);
	}
	
	public Employee searchById(int id) {
		
		return repo.searchById(id);
	}


	public Employee updateById(int id,double salary) {
		// TODO Auto-generated method stub
		return repo.updateById(id,salary);
	}


	public void  deleteById(int id) {
		 repo.deleteById(id);
		
		
	}
	
}



