package com.cg.mobile.service;
import java.sql.SQLData;
import java.time.LocalDate;
import java.util.*;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;
import com.exceptions.MobileException;

public interface IMobileService 
{
	public String display();
	 public List<Mobile> getMobileByPrice(double price);
	 public List<Mobile> getAllMobile();
	 public String deleteMobile(int mobileId);
	 public int storeDetails(Customer customer) throws MobileException;

		public boolean validateFileds(Customer customer) throws MobileException;
		//public  changeDate();
		public java.sql.Date changeDate(LocalDate date);
	 
}
