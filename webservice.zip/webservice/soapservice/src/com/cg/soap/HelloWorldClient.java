package com.cg.soap;

import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.MalformedInputException;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class HelloWorldClient {

	public static void main(String[] args) throws  MalformedURLException
	{
		URL u=new URL("http://localhost:7800/hs?wsdl");
		QName q=new QName("http://soap.cg.com/", "HelloWorldImplService");
		Service s=Service.create(u, q);
		HelloWorld hw=s.getPort(HelloWorld.class);
		
		System.out.println(hw.sayHello());

	}

}

