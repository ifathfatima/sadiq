package SirClassprog;

interface Bik
{
	  void runi();
	 void speedi();
	
}
  class  Interface1 implements Bik
{
	public  void runi()				//without giving public  for this fn it wo'nt work 
		{
			System.out.println("runn methos");				//and we also should define all the fn of interface in this class
																//otherwise error comes
		}
	public  void speedi()
		{
			System.out.println("speed methos");
		}
	 public static void main(String[] args)
	 {
			// TODO Auto-generated method stub
			Interface1 in= new Interface1();
			in.runi();
			in.speedi();
			
	 }
}

