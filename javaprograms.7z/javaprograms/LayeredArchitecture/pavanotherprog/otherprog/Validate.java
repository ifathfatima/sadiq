package otherprog;
import java.util.*;
import java.util.regex.Pattern;

import otherprog.MainClass.*;

public class Validate
{
	
	public boolean isName(String name)
	{
		boolean b=Pattern.matches("[A-Z][a-z]+",name);
		return b;
		
	}
	public boolean isPhone(long ph)
	{
		boolean b1=Pattern.matches("[6-9][0-9]{9}",Long.toString(ph));
		return b1;
	}
	
	
	
	
}
