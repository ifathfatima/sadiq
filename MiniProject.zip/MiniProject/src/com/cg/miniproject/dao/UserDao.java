package com.cg.miniproject.dao;

import java.sql.Connection;




import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;

import org.apache.log4j.Logger;






import com.cg.miniproject.Bean.*;



public class UserDao {
	
	
	//PropertiesConfigurator.configure("log4j.properties");
	
	 //static Logger logger = Logger.getLogger(UserDao.class);
	 
	 
	 
	 
	Connection con = null;
	//Statement s=null;
	PreparedStatement ps = null;

	public Connection getConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String user = "system";
			String pass = "Capgemini123";
			con = DriverManager.getConnection(url, user, pass);
			return con;

		} catch (Exception e) {

			e.printStackTrace();

		}

		return con;

	}
	
//================================================================
	//logger.info("checking whether user is librarian or student");
	
	public String getUserStatus(String user) {

		String s=null;

		try {

		con = getConnection();

		ps = con.prepareStatement("select librarian from user_info where user_name=?");

		ps.setString(1,user);

		ResultSet rs = ps.executeQuery();

		while(rs.next()){

		s= rs.getString("librarian");

		}

		return s;

		} catch(Exception e) {e.printStackTrace();}

		return null;

		}

	
	
	
	
	//logger.info("register a book in D.B");
	
		public int registerBook(String RegId,String BookId,String userId)

		{

		con=getConnection();

		String sql="insert into bookregistration values(?,?,?,sysdate)";

		try {

		ps=con.prepareStatement(sql);

		ps.setString(1, RegId);

		ps.setString(2,BookId);

		ps.setString(3,userId);

		int n= ps.executeUpdate();

		return n;

		} catch (SQLException e) {

		e.printStackTrace();

		}

		return 0;

		}
	
	
		
		
		//logger.info("checking whether user is valid or not");
	public boolean validateUser(String username)
		{
			con = getConnection();
			String sql = "select password from user_info where user_name=?";
			
			try{
				ps=con.prepareStatement(sql);
				ps.setString(1,username);
				
				
				ResultSet rs=ps.executeQuery();
				return rs.next();
				//String uname=rs.getString(1);
				
				
				
				
			}
			catch (Exception e) {

				return false;
			}
			
		}

	
	//========================================================
	
	
	
	
	
	
	
	//adding the details to book inventory table
	public int addBook(String id,String name,String author1,String author2,String publisher,String yearofpublish)
	{
		con = getConnection();
		String sql = "insert into bookinventory values(?,?,?,?,?,?)";

		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, id);
			ps.setString(2, name);
			ps.setString(3, author1);
			ps.setString(4, author2);
			ps.setString(5, publisher);
			ps.setString(6,yearofpublish );
			int n = ps.executeUpdate();
			return n;
		}

		catch (Exception e) {

			e.printStackTrace();
		}
		return 0;
		
	
	}
	
	
	
	
	public int deleteBook(String id)
	{
		con = getConnection();
		String sql = "delete from bookinventory  where book_id=?";

		try {
			ps = con.prepareStatement(sql);
			
			ps.setString(1, id);

			int n = ps.executeUpdate();
			return n;
		}

		catch (Exception e) {

			e.printStackTrace();
		}
		return 0;
	}
	
	
	public int updateBooK(String id,String name)
	{
		
		
		con = getConnection();
		String sql = "update  bookinventory set book_name=?  where book_id=?";

		try {
			ps = con.prepareStatement(sql);
			
			ps.setString(2, id);
			ps.setString(1, name);
			

			int n = ps.executeUpdate();
			return n;
		}

		catch (Exception e) {

			e.printStackTrace();
		}
		return 0;
	}
	
	
	
	
	
	public int addTransaction(String tid,String rid,String returndate)
	{
		con=getConnection();
		      String sql="insert into booktransaction values(?,?, SYSDATE, ?, ?,SYSDATE+15)";
		      try{
		      ps = con.prepareStatement(sql);
		      ps.setString(1, tid);
		      ps.setString(2, rid);
		      
		       
		      Date date1=new SimpleDateFormat("yyyy-MM-dd").parse(returndate);  
		      
		      java.sql.Date sDate1 = convertUtilToSql(date1);
		      
		      
		     

		      //settig the returndate to D>B by converting into sql format
		     ps.setDate(3, sDate1 );
		     
		     
		      
		      
		      DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		     
		      
		      String todaydate = dateFormat.format(new Date());  
		      //System.out.println(todaydate); //sysdate
		      
		     String dt[] = todaydate.split("-");
		      
		      
		      
		      
		      
		      
		      String rd[] = returndate.split("-");
		      
		     int fine = 0;
		     /*
		     
		     if(Integer.parseInt(rd[0])>=Integer.parseInt(dt[0]))
		     {
		     
		      if(Integer.parseInt(rd[1])>=Integer.parseInt(dt[1]))
		      {
		    	 if(Integer.parseInt(rd[2])>=(15+Integer.parseInt(dt[2])))
		    	 {
		    		 
		    		 DateTimeFormatter d1= DateTimeFormatter.ofPattern("yyyy-mon-d");
		    		 
		    		 
		    		 LocalDate l1=LocalDate.parse(returndate,d1);
		    		 
		    		 LocalDate l2=LocalDate.parse(todaydate,d1);
		    		 
		    		// Period p1=Period.between(returndate, todaydate);
		    		 long p2=ChronoUnit.DAYS.between(l1, l2);
		    		 System.out.println(p2);
		    		 
		    		  fine=(Integer.parseInt(rd[2]))-(15+Integer.parseInt(dt[2]));
		    	}
		      }
		      
		     }
		     */
		      System.out.println(fine);
		      ps.setInt(4, fine);
		      
		      
		      
		      int n=ps.executeUpdate();
		      return 1;
		      
		      }catch(Exception e){
		      e.printStackTrace();
		      }
		      return 0;
		     }
	
	
	
	
	 private static java.sql.Date convertUtilToSql(java.util.Date uDate)
     {
   	 
   	          java.sql.Date sDate = new java.sql.Date(uDate.getTime());
   	 
   	          return sDate;
   	  
   	      }
}