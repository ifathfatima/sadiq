package Lab_8;							//8.1 working but  not correct

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.*;


public class FileRev 
{

	public static void main(String[] args)
	{
		try
		{
			FileReader fr= new FileReader("D:\\abc.txt");
			FileWriter fw=new FileWriter("D:\\bcd.txt");    		//donot create this file the vprog will create on its own
			BufferedReader br = new BufferedReader(fr);  
			String data; 
			while ((data = br.readLine()) != null)
			{
			    String[] words = data.split(" ");
			    for(String a: words)
			    {
			        StringBuilder builder=new StringBuilder(a);
			        fw.write(builder.reverse().toString());
			    }  
			}
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
	}
}