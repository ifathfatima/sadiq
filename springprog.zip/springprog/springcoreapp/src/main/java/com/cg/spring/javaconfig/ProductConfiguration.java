package com.cg.spring.javaconfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;




@Configuration
@ComponentScan(basePackages="com.cg.spring.javaconfig")
public class ProductConfiguration {
	
	
	
	@Bean
	public Product getProduct()

	{
		Product  p=new Product();
		p.setProductname("apple");
		p.setProductprice(10000);
		return p;
		
	}
	
	
	@Bean
	public User getUser()
	{
		User u=new User();
		u.setName("ifath");
		
		return u;
		
	}
	
	 
	
	
	

}
