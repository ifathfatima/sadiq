package com.cg.mobile.bean;

import java.util.Date;

public class Customer 
{
	private String cname;
	private long cph;
	private String cmailid;
	private Date date;
	private int mobileId;
	private int quantity;
	
	
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public long getCph() {
		return cph;
	}
	public void setCph(long cph) {
		this.cph = cph;
	}
	public String getCmailid() {
		return cmailid;
	}
	public void setCmailid(String cmailid) {
		this.cmailid = cmailid;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	public void setMobileId(int mobileId)
	{
		this.mobileId=mobileId;
	}
	public int getMobileId()
	{
		return mobileId;
	}
	public int getquantity() {
		return quantity;
	}

	public void setquantity(int quantity) {
		this.quantity = quantity;
	}
	public Customer(String cname, long cph, int quantity) {
		super();
		this.cname = cname;
		this.cph = cph;
		this.quantity = quantity;
	}
}