package com.cg.operators;

public class Increment {

	public static void main(String[] args) {
		int x=2;
		System.out.println("increment is"+x++); //2
		System.out.println(" after increment is"+x);  //3
		
		
		
		int p=4;
		System.out.println("pre-increment"+(++p));  //5
		
		int y=3;
		System.out.println("drecrement  is"+y--);   //3
		System.out.println(" after drecrement is"+y);   //2
		
		
		int z=6;
		System.out.println("pre drecrement"+--z);   //5
		
		// TODO Auto-generated method stub

	}

}
