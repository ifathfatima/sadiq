package com.capgemini.emp.bean;
//import com.capgemini.emp.dao.*;
import java.util.*;


public  class Employee 
{
	public static  String name;
	 public static  long ph;
	 public static  String rol;
	public static double sal;
	public static String mail;
	public static double TA;
	public static  int id;
	/*public static void setDetails()
	{
		
	Scanner sc= new Scanner(System.in);
	
	name =sc.next();
	//System.out.println("Enter the name of the Employee : "+name);
	ph=sc.nextLong();
	//System.out.println("Enter Employee phone number: "+ph);
	rol=sc.next();
	//System.out.println("Enter Employee phone number: "+ph);
	sal=sc.nextDouble();
	
	//System.out.println("Salary:"+sal);
	mail=sc.next();
	
	//Random r=new Random();
	//id=r.nextInt(50);				//for setting id randomly
	
	
	//System.out.println("mail id:"+mail);
	//String uniqueID = UUID.randomUUID().toString();
	//System.out.println("employee has been succesfully register along with id:10001");
	
	}
	public static void getDetails()
	{
		Random r=new Random();
		id=r.nextInt(50);	
		System.out.println("Enter the name of the Employee : "+name);
		System.out.println("Enter Employee phone number: "+ph);
		System.out.println("Enter role is: "+rol);
		System.out.println("Salary:"+sal);
		System.out.println("mail id:"+mail);
		 
		System.out.println("employee has been succesfully register along with id:"+id);
	}
	*/
	
	
}
