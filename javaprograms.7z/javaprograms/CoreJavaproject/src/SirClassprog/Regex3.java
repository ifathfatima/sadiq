package SirClassprog;
import java.util.regex.*;
import java.util.*;


public class Regex3 {

	public static void main(String[] args) {
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the patter:");
		
		Pattern p= Pattern.compile(sc.nextLine());
		
		System.out.println("enter the string to be compared:");
		Matcher m=p.matcher(sc.nextLine());
		boolean f=m.matches();
		System.out.println(f);


		
		

	}

}
