package com.cg.eis.exception;						//9.2.2 prog
import org.junit.*;

import com.cg.eis.exception.EmpException.*;
import com.cg.eis.bean.Employee;

import static org.junit.Assert.*; 

public class ExceptionTest 
{
		
	@Test(expected=EmpException.class)
	public void testException() 
	{
		Employee e3= new Employee(102,"hashu",20000l,"associate");
		EmpException e=new EmpException();
		asserEquals("sal is then 3000",e.getMessage());
		
	}

	
	
	
	/*
	 * @Test(expected=EmpException.class)
	public void testException()
	{
		
		try
		{
			Employee e3= new Employee(102,"hashu",200l,"associate");
		
		 EmpException obj = new EmpException();
		 obj.getMessage();
		}
		  catch (Exception e) 
		{
	            assertThat(e.getMessage().equals("sal is less than 3000"));
	     }
		
		
	}
	*/

	
	
}
