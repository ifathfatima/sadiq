package Lab_8;				//8.1 prog correct
import java.io.*;
import java.util.*;
import java.lang.*;

public class EvenCon 
{

	public static void main(String[] args) throws IOException
	{
	
		File fi = new File("D:\\number.txt");

		Scanner content=new Scanner(fi);

		String s=content.nextLine();   //s is holding "1,2,3,4,5,6,7,8,9,10"

		StringTokenizer st = new StringTokenizer(s,",");

		while (st.hasMoreTokens())

		{

		int i=Integer.parseInt(st.nextToken());

		if(i%2==0)

		System.out.println(i);

		}

		}
	

}
