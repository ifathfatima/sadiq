let person={
	name:'ifath',
	display()
	{
	document.write("hello:"+this.name+"<br>");
	}
}

let employee={
	salary:9000,
	print()
	{
	document.write("your sal is:"+this.salary+"<br>");
	},
	display()
	{
		super.display();
		document.write("method overriding<br>");	
	}
}


employee.__proto__=person;
employee.print();
document.write("\n");

employee.display();






var emp={id:1,name:'ifathfatima',city:'hyd'}
var json=JSON.stringify(emp);
document.write(json);	
