package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.example.bean.Product;
import com.example.repository.IProductRepo;

@Component
public class ProductService implements IProductService {

	
	
	
	@Autowired
	IProductRepo repo;
	
	
	
	
	public List<Product> getAllProduct() {
		
		return repo.getAllProduct();
		}

	
	public Product getProductById(int id) {
		
		return repo.getProductById(id);
		
	}


	@Override
	public List<Product> delete(int id) {
		
		return repo.delete(id);
	}


	@Override
	public String addProduct(String name,double price) {
		
		return repo.addProduct(name,price);
	}


	@Override
	public String updateProduct(int id,String name, double price) {
		
		return repo.updateProduct(id,name, price);
	}

	
	
	
	
}
