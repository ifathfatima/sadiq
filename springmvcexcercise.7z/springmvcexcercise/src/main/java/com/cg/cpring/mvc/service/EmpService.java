package com.cg.cpring.mvc.service;

import java.util.List;

import org.springframework.stereotype.Service;


import com.ch.spring.mvc.bean.Employee;

@Service
public interface EmpService {
	
	List<Employee> getEmployee();
	
	
	void add(Employee p);
	
	
	Employee searchById(int id);
	
	 Employee updateById(int id,double salary);
	 
	  void  deleteById(int id);
	
	

}
