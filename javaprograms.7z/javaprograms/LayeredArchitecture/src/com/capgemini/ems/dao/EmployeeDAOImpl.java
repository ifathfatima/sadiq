package com.capgemini.ems.dao;

public class EmployeeDAOImpl  implements EmployeeDAO
{

}
