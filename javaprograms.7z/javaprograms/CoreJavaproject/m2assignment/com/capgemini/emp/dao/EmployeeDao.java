package com.capgemini.emp.dao;
import java.lang.*;

import com.capgemini.emp.bean.*;
//import com.capgemini.emp.service.*;

/*interface IEmployeeDao 
{ 
int addEmployee (Employee emp);
Employee getEmployee (int empId);
}
*/
 public class EmployeeDao
 {
	public  void getRol()
	 {
	if(Employee.rol.equals("seniormanager"))
	{
		Employee.TA=0.25*(Employee.sal);
	}
	else if(Employee.rol.equals("manager"))
	{
		Employee.TA=0.20*(Employee.sal);
	}
	else if(Employee.rol.equals("seniorconsultant"))
	{
		Employee.TA=0.15*(Employee.sal);
	}
	else if(Employee.rol.equals("consultant"))
	{
		Employee.TA=0.10*(Employee.sal);
	}
	else
	{
		System.out.println("the role entered is invalid");
	}
	
	System.out.println("travel allowence is:"+Employee.TA);
	 }
 }




