package com.cg.javaObj;

public class Student 
{
		int mat=100,sci=67,soci=90;
		String name="ifath";
		int avg=(mat+sci+soci)/3;
		String ch;
		  void comScore()
		{
			 System.out.println("average is"+avg);
			// if(avg>60)
			// {
			//	 System.out.println("pass");
			// }
			// else
			 //{
			//	 System.out.println("fail");
			 //}
			 ch=(avg>60)?"pass":"fail";
			 System.out.println(ch);
			 
		}
		void display()
		{
			System.out.println("name:"+name);
			
		}
		
public static void main(String[] args)
{
	// TODO Auto-generated method stub
	Student s= new Student();
	s.display();
	s.comScore();
	

}

}
