package Lab_8;				//8.3 2nd/3rd prog   correct prog but the output in file is not in prpoer format

import java.io.IOException;

import Lab_8.*;
import Lab_8.Service.*;
public class EmpMain 
{

	public static void main(String[] args) throws IOException,ClassNotFoundException
	{
		//Employee e1= new Employee(101,"ifath",20000l,"engineer");
		Service s= new Service();
		s.add();
		
		
		
		//s.methodi(20000l,"engineer");
		//s.display();
	}

}
