package com.cg.operators;

public class relational {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int x=4, y=8;
		System.out.println(x>y );
		System.out.println(x<y );
		System.out.println(x==y);
		System.out.println(x>=y);
		System.out.println(x<=y);
		System.out.println(x!=y);

	}

}
