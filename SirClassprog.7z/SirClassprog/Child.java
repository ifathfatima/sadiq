package SirClassprog;

class Parent
{
	void m1()
	{
		System.out.println("parent");
	}

}
class  Child extends Parent
{
	void m1()
	{
		//super.m1();
		System.out.println("child");
	}
	public static void main(String args[])
	{
		Parent p=new Child();			//downcating 
		Child c=new Child();
		//p=(Parent)c;			//upcating
		//p.m1();
		c=(Child)p;
		c.m1();
		
	}
}