package Lab_8;

public class Delete {

}
