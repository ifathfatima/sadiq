package com.cg.library;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class UpdateLibrary

{

public static void main(String[] args) {
		
		EntityManagerFactory emf2=Persistence.createEntityManagerFactory("Library Management");
		EntityManager em2=emf2.createEntityManager();
		em2.getTransaction().begin();
		
		
		
		System.out.println("enter the id for which you want  to update");
		Scanner sc=new Scanner(System.in);
		
		//int id=sc.nextInt();
		Library l2=em2.find(Library.class, sc.nextInt());
		
		if(l2==null)
		{
			System.out.println("the book is not there in D.B");
		}
		else
		{
			System.out.println("enter the name for book");
			String name=sc.next();
			System.out.println("enter the price for book");
			double price=sc.nextDouble();
			l2.setBookname(name);
			l2.setBookprice(price);
			em2.persist(l2);
			
			System.out.println("updated the value");
		}
		
		
		
		em2.getTransaction().commit();
		em2.close();
		emf2.close();
		
	
	
	
}
}
