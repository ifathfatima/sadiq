package com.cg.library;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PersistLibrary 
{

	public static void main(String[] args) 
	{
		
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("Library Management");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		Library l1=new Library();
		l1.setBookname("java");
		l1.setBookprice(399.00);
		
		Library l2=new Library();
		l2.setBookname("angular");
		l2.setBookprice(1399.00);
		em.persist(l1);		//create one row in library table the order these rows in D.B is random
		em.persist(l2);		//creates another row in library table
		
		
		em.getTransaction().commit();
		em.close();
		emf.close();
		
		
		
	}

}
